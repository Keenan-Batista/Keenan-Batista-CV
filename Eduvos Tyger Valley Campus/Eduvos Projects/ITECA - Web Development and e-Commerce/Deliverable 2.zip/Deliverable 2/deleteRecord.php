<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recordID = $_POST["formBtn"];
    $recordType = $_POST["recordType"];
    $userType = $_SESSION["userType"];
    $connectionActive = false;
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    if (isset($_POST["userType"])){
        $userType = $_POST["userType"];
    }
    
    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $_SESSION["message"] = "Account has been deleted successfully";
        if ($recordType != "listing" && $recordType != "delivery"){
            if ($recordType != "admin"){
                $deliveryID = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT deliveryID FROM delivery WHERE userID = ?", [$recordID]));  
                mysqli_execute_query($connection, "Delete FROM delivery WHERE userID = ?", [$recordID]);
                mysqli_execute_query($connection, "DELETE FROM deliveryMessage WHERE deliveryID = ?", [$deliveryID["deliveryID"]]);
                mysqli_execute_query($connection, "Delete FROM cartItem WHERE deliveryID = ?", [$deliveryID["deliveryID"]]);

                if ($recordType == 'vendor'){
                    $listingDetails = mysqli_execute_query($connection, "SELECT * FROM listing WHERE vendorID = ?", [$recordID]);
                    if(mysqli_num_rows($listingDetails) > 0){
                        while($recordDetails = mysqli_fetch_array($listingDetails)){
                            unlink(substr($recordDetails["image"], 3));
                            $cartItemDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE listingID = ?", [$recordDetails["listingID"]]));
                            mysqli_execute_query($connection, "Delete FROM listing WHERE listingID = ?", [$recordDetails["listingID"]]);
                            mysqli_execute_query($connection, "Delete FROM cartItem WHERE listingID = ?", [$recordDetails["listingID"]]);

                            $deliveryCartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ?", [$cartItemDetails["deliveryID"]]);
                            if (mysqli_num_rows($deliveryCartItems) <= 0){
                                mysqli_execute_query($connection, "DELETE FROM delivery WHERE deliveryID = ?", [$cartItemDetails["deliveryID"]]);
                                mysqli_execute_query($connection, "DELETE FROM deliveryMessage WHERE deliveryID = ?", [$cartItemDetails["deliveryID"]]);
                            }
                        }
                    }
                }

                if ($userType != "admin"){
                    unset($_SESSION["userID"]);
                    unset($_SESSION["firstName"]);
                    unset($_SESSION["lastName"]);
                    unset($_SESSION["username"]);
                    unset($_SESSION["phoneNum"]);
                    unset($_SESSION["email"]);
                    unset($_SESSION["address"]);
                    unset($_SESSION["userType"]);
                }
                $_SESSION["message"] = "Account has been deleted successfully";
            }
        }
        else if ($recordType == "listing") {
            $listingDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$recordID]));
            $cartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE listingID = ?", [$recordID]);
            mysqli_execute_query($connection, "Delete FROM cartItem WHERE listingID = ?", [$recordID]);
            
            if(mysqli_num_rows($cartItems) > 0){
                while($cartItemDetails = mysqli_fetch_array($cartItems)){
                    $deliveryCartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ?", [$cartItemDetails["deliveryID"]]);
                    if (mysqli_num_rows($deliveryCartItems) <= 0){
                        mysqli_execute_query($connection, "DELETE FROM delivery WHERE deliveryID = ?", [$cartItemDetails["deliveryID"]]);
                        mysqli_execute_query($connection, "DELETE FROM deliveryMessage WHERE deliveryID = ?", [$cartItemDetails["deliveryID"]]);
                    }
                    else{
                        $deliveryDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM delivery WHERE deliveryID = ?", [$cartItemDetails["deliveryID"]]));
                        mysqli_execute_query($connection, "UPDATE delivery SET totalCost = ? WHERE deliveryID = ?", [($deliveryDetails["totalCost"] - ($listingDetails["price"] * $cartItemDetails["quantity"])), $cartItemDetails["deliveryID"]]);
                    }
                }
            }
        }
        else{
            mysqli_execute_query($connection, "Delete FROM cartItem WHERE deliveryID = ?", [$recordID]);
            $_SESSION["message"] = "Delivery has been cancelled successfully";
        }

        $listingDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$recordID]));
        mysqli_execute_query($connection, "Delete FROM $recordType WHERE ". $recordType ."ID = ?", [$recordID]);
        if ($recordType == "listing") {
            unlink(substr($listingDetails["image"], 3));
            $_SESSION["message"] = "Listing has been deleted successfully";
        }
        else if ($recordType == "delivery"){
            mysqli_execute_query($connection, "DELETE FROM deliveryMessage WHERE deliveryID = ?", [$recordID]);
        }
        mysqli_commit($connection);
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
}
else{
    $_SESSION["message"] = "Error: POST error occured";
}
echo "</div>";

if ($userType != "admin"){
    if ($recordType != "listing" && $recordType != "delivery"){
        header('Location:index.php');
    }
    else if ($recordType == "listing"){
        header('Location:mainWebsite/accountCenter(ProfileDetails).php');
    }
    else{
        if ($userType == "user"){
            header('Location:mainWebsite/cart.php');
        }
        else{
            header('Location:mainWebsite/accountCenter(Deliveries).php');
        }
    }
}
else{
    header('Location:adminWebsite/'. $recordType .'Database.php');
}
?>