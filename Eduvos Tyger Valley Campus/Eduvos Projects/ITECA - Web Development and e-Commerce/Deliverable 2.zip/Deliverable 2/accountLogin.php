<?php
echo "<link rel='stylesheet' href='style.css'>";
echo "<div class='form-accountDetails'>";
$userType = null;
$success = false;
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        $username = $_POST["username"];
        $password = $_POST["password"];
        $errors = [];

        if (empty($username)) {
            $errors[] = "Username is required";
        }
        if (empty($password)) {
            $errors[] = "Password is required";
        }

        if (!empty($username) && !empty($password)) {
            $sqlUsernameB = mysqli_execute_query($connection, "SELECT * FROM buyer WHERE username = ?", [$username]);
            
            if (mysqli_num_rows($sqlUsernameB) <= 0) {
                $sqlUsernameV = mysqli_execute_query($connection, "SELECT * FROM vendor WHERE username = ?", [$username]);
                
                if (mysqli_num_rows($sqlUsernameV) <= 0) {
                    $sqlUsernameA = mysqli_execute_query($connection, "SELECT * FROM admin WHERE username = ?", [$username]);
                    
                    if (mysqli_num_rows($sqlUsernameA) <= 0) {
                        $errors[] = "Username or password is incorrect";
                    }
                    else{
                        $userDetails = mysqli_fetch_array($sqlUsernameA);
                        if (password_verify($password, $userDetails["password"])){
                            $userType = "admin";
                        }
                        else{
                            $errors[] = "Username or password is incorrect";
                        }    
                    }
                }
                else{
                    $userDetails = mysqli_fetch_array($sqlUsernameV);
                    if (password_verify($password, $userDetails["password"])){
                        $userType = "vendor";
                    }
                    else{
                        $errors[] = "Username or password is incorrect";
                    }                   
                }
            }
            else{
                $userDetails = mysqli_fetch_array($sqlUsernameB);
                if (password_verify($password, $userDetails["password"])){
                    $userType = "buyer";
                }
                else{
                    $errors[] = "Username or password is incorrect";
                }    
            }
        }

        if (empty($errors)) {
            $userDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM $userType WHERE username = ?", [$username]));

            unset($_SESSION["userID"]);
            unset($_SESSION["firstName"]);
            unset($_SESSION["lastName"]);
            unset($_SESSION["username"]);
            unset($_SESSION["phoneNum"]);
            unset($_SESSION["email"]);
            unset($_SESSION["address"]);
            unset($_SESSION["userType"]);

            $_SESSION["userID"] = $userDetails[$userType."ID"];
            $_SESSION["username"] = $userDetails["username"];
            $_SESSION["userType"] = $userType;

            if ($userType != "admin"){
                $_SESSION["firstName"] = $userDetails["firstName"];
                $_SESSION["lastName"] = $userDetails["lastName"];
                $_SESSION["phoneNum"] = $userDetails["phoneNum"];
                $_SESSION["email"] = $userDetails["email"];
                $_SESSION["address"] = $userDetails["address"];
            }

            $_SESSION["message"] = "Account logged in successfully";
            $success = true;
        }
        else {
            echo "<h1>Account login error</h1>";
            echo "<h3>Account couldn't be logged into due to the following error(s):</h3>";
            echo "<div class='form-errorBoard error'>";
            foreach ($errors as $error) {
                echo "<h4>*$error</h4>";
            }
            echo "</div>";
            echo "<a href='accountLogin.html' class='form-returnLink'>Return to login page</a>";
        }
    }
    catch(Exception $error){
        echo "<h1>Account login error</h1>";
        echo "<h3>Account couldn't be logged into due to the following error(s):</h3>";
        echo "<div class='form-errorBoard error'>";
            echo "<h4>*Error: ". $error->getMessage() ."</h4>";
        echo "</div>";
        echo "<a href='accountLogin.html' class='form-returnLink'>Return to login page</a>";
    }
    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}
echo "</div>";

if ($success == true){
    if ($userType != "admin"){
        header('Location:index.php');
    }
    else{
        header('Location:adminWebsite/adminDatabase.php');
    }
}
?>