<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $success = true;
    $listingID = $_POST["updateBtn"];
    $stock = $_POST["stock"];
    $connectionActive = false;
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        if ($stock != null){
            if ($stock < 1){
                $_SESSION["message"] = "Error: Invalid stock";
                $success = false;
            }
        }
        else{
            $_SESSION["message"] = "Error: stock is required";
            $success = false;
        }

        if ($success == true) {
            mysqli_execute_query($connection, "Update listing SET inStock = $stock WHERE listingID = ?", [$listingID]);

            $listingItem = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$listingID]));
            $cartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE listingID = ?", [$listingID]);
            while($cartItem = mysqli_fetch_array($cartItems)){
                if ($cartItem["quantity"] > $listingItem["inStock"]){
                    $quantityReduction = $cartItem["quantity"] - $listingItem["inStock"];
                    $totalCost = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT totalCost FROM delivery WHERE deliveryID = ?", [$cartItem["deliveryID"]]));
                    $newCost = $totalCost["totalCost"] - ($listingItem["price"] * $quantityReduction);

                    mysqli_execute_query($connection, "UPDATE cartItem SET quantity = ? WHERE cartItemID = ?", [($cartItem["quantity"] - $quantityReduction), $cartItem["cartItemID"]]);
                    mysqli_execute_query($connection, "UPDATE delivery SET totalCost = ? WHERE deliveryID = ?", [$newCost, $cartItem["deliveryID"]]);
                }
            }

            $_SESSION["message"] = "Listing's stock has been updated successfully";
            mysqli_commit($connection);
        }
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

header('Location:accountCenter(ProfileDetails).php');
?>