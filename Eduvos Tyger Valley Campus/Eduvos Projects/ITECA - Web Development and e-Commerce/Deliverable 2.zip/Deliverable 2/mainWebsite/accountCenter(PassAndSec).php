<?php
session_start();
if (!isset($_SESSION["userID"]) && empty($_SESSION["userID"])){
    header('Location:index.php');
}
echo "<html lang='en'>";

echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>My Account</title>";
    echo "<link rel='stylesheet' href='../style.css'>";
echo "</head>";

if (isset($_SESSION["message"]) && !empty($_SESSION["message"])){
    echo "<div id='message' name='message' class='msg'>";
        echo "<p>". $_SESSION["message"] ."</p>";
        echo "<button onclick='closeMessage()'>X</button>";
    echo "</div>";
    unset($_SESSION["message"]);
    echo "<script src='../script.js'></script>";
}

echo "<header>";
    echo "<h1><a href='index.php'>Marketplace</a></h1>";
    echo "<div class='form-mainHeading'>";
        echo "<div class='form-account'>";
            echo "<a href='index.php'>Return to the store front</a>";
        echo "</div>";
    echo "</div>";
echo "</header>";

echo "<body>";
    echo "<div class='form-accountCenter'>";
        echo "<div class='vr form-accountCenterOptions'>";
            echo "<h1 >Account Center</h1>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(ProfileDetails).php'>Profile details</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem form-accCenterOptionPicked'>";
                echo "<a href='accountCenter(PassAndSec).php'>Password and security</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(UserRatings).php'>User ratings</a>";
            echo "</div>";

            if ($_SESSION["userType"] == "vendor"){
                echo "<div class='form-accountCenterOptionsItem'>";
                    echo "<a href='accountCenter(Deliveries).php'>Ongoing deliveries</a>";
                echo "</div>";
            }
        echo "</div>";

        echo "<div class='form-settingOptions'>";
            echo "<div class='form-settingOptionsSideItems'>";
                echo "<div class='form-inputDetails'>";
                    echo "<form action='../changePasswordForm.php' method='POST'>";
                        echo "<input type='hidden' value='". $_SESSION["userType"] ."' name='userType' id='userType'>";
                        echo "<button type='submit' value='". $_SESSION["userID"] ."' id='formBtn' name='formBtn'>Change password</button>";
                    echo "</form>";
                echo "</div>";

                echo "<div class='form-inputDetails'>";
                    echo "<form action='../deleteRecord.php' method='POST'>";
                        echo "<input type='hidden' value='". $_SESSION["userType"] ."' name='recordType' id='recordType'>";
                        echo "<button type='submit' value='". $_SESSION["userID"] ."' id='formBtn' name='formBtn'>Delete account</button>";
                    echo "</form>";
                echo "</div>";
            echo "</div>";
        echo "</div>";
    echo "</div>";
echo "</body>";

echo "</html>";
?>