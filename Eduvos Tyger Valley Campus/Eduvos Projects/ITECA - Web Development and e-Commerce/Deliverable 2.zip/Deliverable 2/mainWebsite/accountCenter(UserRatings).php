<?php
session_start();
if (!isset($_SESSION["userID"]) && empty($_SESSION["userID"])){
    header('Location:index.php');
}
$username = $_SESSION["username"];

echo "<html lang='en'>";
echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>My Account</title>";
    echo "<link rel='stylesheet' href='../style.css'>";
echo "</head>";

if (isset($_SESSION["message"]) && !empty($_SESSION["message"])){
    echo "<div id='message' name='message' class='msg'>";
        echo "<p>". $_SESSION["message"] ."</p>";
        echo "<button onclick='closeMessage()'>X</button>";
    echo "</div>";
    unset($_SESSION["message"]);
    echo "<script src='../script.js'></script>";
}

echo "<header>";
    echo "<h1><a href='index.php'>Marketplace</a></h1>";
    echo "<div class='form-mainHeading'>";
        echo "<div class='form-account'>";
            echo "<a href='index.php'>Return to the store front</a>";
        echo "</div>";
    echo "</div>";
echo "</header>";

echo "<body>";
    echo "<div class='form-accountCenter'>";
        echo "<div class='vr form-accountCenterOptions'>";
            echo "<h1 >Account Center</h1>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(ProfileDetails).php'>Profile details</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(PassAndSec).php'>Password and security</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem form-accCenterOptionPicked'>";
                echo "<a href='accountCenter(UserRatings).php'>User ratings</a>";
            echo "</div>";
            
            if ($_SESSION["userType"] == "vendor"){
                echo "<div class='form-accountCenterOptionsItem'>";
                    echo "<a href='accountCenter(Deliveries).php'>Ongoing deliveries</a>";
                echo "</div>";
            }
        echo "</div>";

        echo "<div class='form-settingOptions'>";
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            $connection = null;
            
            try{
                $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
                echo "<div class='form-title'>";
                    $recordFound = false;
                    if ($_SESSION["userType"] == "vendor"){
                        $ratings = mysqli_execute_query($connection, "SELECT * FROM userRatingHistory WHERE vendorID = ? AND rated = '0' AND ratingType ='buyer'", [$_SESSION["userID"]]);
                        
                        if(mysqli_num_rows($ratings) > 0){
                            $recordFound = true;
                            echo "<h2>Provide buyer ratings</h2>";
                            while($ratingDetails = mysqli_fetch_array($ratings)){
                                $vendorDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM ". $ratingDetails["userType"] ." WHERE ". $ratingDetails["userType"] ."ID = ?", [$ratingDetails["userID"]]));
                                echo "<h2>". $vendorDetails["username"] ."</h2>";
                                echo "<form action='rateUser.php' method='POST'>";
                                    echo "<input type='hidden' id='userType' name='userType' value='". $ratingDetails["userType"] ."'>";
                                    echo "<input type='hidden' id='ratingType' name='ratingType' value='buyer'>";
                                    echo "<input type='range' min=1 max=5 id='rating' name='rating'>";
                                    echo "<button type='submit' name='formBtn' id='formBtn' value='". $ratingDetails["userID"] ."'>Confirm rating</button>";
                                echo "</form>";
                            }
                        }
                    }

                    $ratings = mysqli_execute_query($connection, "SELECT * FROM userRatingHistory WHERE userType = ? AND userID = ? AND rated = '0' AND ratingType ='vendor'", [$_SESSION["userType"], $_SESSION["userID"]]); 
                    if(mysqli_num_rows($ratings) > 0){
                        $recordFound = true;
                        echo "<h2>Provide vendor ratings</h2>";
                        while($ratingDetails = mysqli_fetch_array($ratings)){
                            $vendorDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM vendor WHERE vendorID = ?", [$ratingDetails["vendorID"]]));
                            echo "<h2>". $vendorDetails["username"] ."</h2>";
                            echo "<form action='rateUser.php' method='POST'>";
                                echo "<input type='hidden' id='userType' name='userType' value='vendor'>";
                                echo "<input type='hidden' id='ratingType' name='ratingType' value='vendor'>";
                                echo "<input type='range' min=1 max=5 id='rating' name='rating'>";
                                echo "<button type='submit' name='formBtn' id='formBtn' value='". $ratingDetails["vendorID"] ."'>Confirm rating</button>";
                            echo "</form>";
                        }
                    }

                    if ($recordFound == false){
                        echo "<h1>* You have no outstanding ratings to give at the moment! *</h1>";
                    }
                echo "</div>";
            }
            catch(Exception $error){
                echo "<h2>An error occured</h2>";
            }

            if ($connection != null){
                $connection->close();
            }
            echo "<script src='../script.js'></script>";
        echo "</div>";
    echo "</div>";
echo "</body>";
echo "</html>";
?>