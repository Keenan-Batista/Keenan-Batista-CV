<?php
$user = "user";
$connectionActive = false;
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $approval = 0;
    if ($_POST["currentApproval"] == 0){
        $approval = 1;
    }
    $deliveryID = $_POST["formBtn"];
    $user = $_POST["userType"];
    
    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        mysqli_execute_query($connection, "UPDATE delivery SET ". $user ."Approval = ? WHERE ". $user ."ID = ?", [$approval, $_SESSION["userID"]]);
        $_SESSION["message"] = "Delivery location approved successfully";
        mysqli_commit($connection);
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

if ($user == "user"){
    header('Location:cart.php');
}
else{
    header('Location:accountCenter(Deliveries).php');
}
?>