<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION["deliveryID"] = $_POST["deliveryID"];
    $_SESSION["otherUserID"] = $_POST["otherUserID"];
    $_SESSION["userTypeOrigin"] = $_POST["formBtn"];
}

$deliveryID = $_SESSION["deliveryID"];
$otherUserID = $_SESSION["otherUserID"];
$userType = $_SESSION["userTypeOrigin"];

if ((!isset($_SESSION["userID"]) && empty($_SESSION["userID"])) || (!isset($_SESSION["deliveryID"]) && empty($_SESSION["deliveryID"]))){
    unset($_SESSION["deliveryID"]);
    unset($_SESSION["otherUserID"]);
    unset($_SESSION["userTypeOrigin"]);
    header('Location:index.php');
}

unset($_SESSION["deliveryID"]);
unset($_SESSION["otherUserID"]);
unset($_SESSION["userTypeOrigin"]);

echo "<html lang='en'>";
echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>Chat form</title>";
    echo "<link rel='stylesheet' href='../style.css'>";
echo "</head>";

if (isset($_SESSION["message"]) && !empty($_SESSION["message"])){
    echo "<div id='message' name='message' class='msg'>";
        echo "<p>". $_SESSION["message"] ."</p>";
        echo "<button onclick='closeMessage()'>X</button>";
    echo "</div>";
    unset($_SESSION["message"]);
    echo "<script src='../script.js'></script>";
}

echo "<header>";
    echo "<h1><a href='index.php'>Marketplace</a></h1>";
    echo "<div class='form-mainHeading'>";
        echo "<div class='form-account'>";
            if ($userType == "user"){
                echo "<a href='cart.php'>Return to the cart</a>";
            }
            else{
                echo "<a href='accountCenter(Deliveries).php'>Return to the Account Center</a>";
            }
        echo "</div>";
    echo "</div>";
echo "</header>";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$connection = null;

echo "<body>";
    echo "<div class='form-accountDetails'>";
        try{
            $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
            $deliveryMessages = mysqli_execute_query($connection, "SELECT * FROM deliveryMessage WHERE deliveryID = ?", [$deliveryID]);
            $deliveryDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM delivery WHERE deliveryID = ?", [$deliveryID]));

            if ($userType == 'user'){
                $otherUserDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM vendor WHERE vendorID = ?", [$otherUserID]));
            }
            else{
                $otherUserDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM ". $deliveryDetails["userType"] ." WHERE ". $deliveryDetails["userType"] ."ID = ?", [$otherUserID]));
            }
            
            echo "<h1>". $otherUserDetails["username"] ."</h1>";
            echo "<hr>";
            echo "<div class='form-cartFlexItemLeft'>";
                if (mysqli_num_rows($deliveryMessages) > 0){
                    while ($deliveryMessage = mysqli_fetch_array($deliveryMessages)){
                        if ($deliveryMessage["userTypeOrigin"] != $userType){
                            echo "<div class='form-leftMessage'>";
                                echo "<p class='form-message '>". $deliveryMessage["message"] ."</p>";
                            echo "</div>";

                            echo "<div class='form-leftMessage form-leftTimeStamp'>";
                                echo "<p class='form-message'>". $deliveryMessage["timeSent"] ."</p><br>";
                            echo "</div>";
                        }
                        else{
                            echo "<div class='form-rightMessage'>";
                                echo "<p class='form-message '>". $deliveryMessage["message"] ."</p>";
                            echo "</div>";

                            echo "<div class='form-rightMessage form-rightTimeStamp'>";
                                echo "<p class='form-message'>". $deliveryMessage["timeSent"] ."</p><br>";
                            echo "</div>";
                        }
                    }
                }
                else{
                    echo "<h1>No messages have been sent yet. You can be the first!</h1>";
                }
            echo "</div>";

            echo "<form action='createMessage.php' method='POST'>";
                echo "<input type='hidden' id='otherUserID' name='otherUserID' value='$otherUserID'>";
                echo "<input type='hidden' id='userType' name='userType' value='$userType'>";
                echo "<div class='form-inputAndBtn'>";
                    echo "<input type='text' id='message' name='message' placeholder='Type a message'>";
                    echo "<button type='submit' name='formBtn' id='formBtn' value='$deliveryID'>&rarr;</button>";
                echo "</div>";
            echo "</form>";
        }
        catch(Exception $error){
            echo "<h2>An error occured</h2>";
        }

        if ($connection != null){
            $connection->close();
        }
        echo "<script src='../script.js'></script>";
    echo "</div>";
echo "</body>";
echo "</html>";
?>