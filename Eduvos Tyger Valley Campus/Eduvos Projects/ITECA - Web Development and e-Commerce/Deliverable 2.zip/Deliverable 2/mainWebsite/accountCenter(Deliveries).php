<?php
session_start();
if (!isset($_SESSION["userID"]) && empty($_SESSION["userID"])){
    header('Location:index.php');
}
$username = $_SESSION["username"];

echo "<html lang='en'>";
echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>My Account</title>";
    echo "<link rel='stylesheet' href='../style.css'>";
echo "</head>";

if (isset($_SESSION["message"]) && !empty($_SESSION["message"])){
    echo "<div id='message' name='message' class='msg'>";
        echo "<p>". $_SESSION["message"] ."</p>";
        echo "<button onclick='closeMessage()'>X</button>";
    echo "</div>";
    unset($_SESSION["message"]);
    echo "<script src='../script.js'></script>";
}

echo "<header>";
    echo "<h1><a href='index.php'>Marketplace</a></h1>";
    echo "<div class='form-mainHeading'>";
        echo "<div class='form-account'>";
            echo "<a href='index.php'>Return to the store front</a>";
        echo "</div>";
    echo "</div>";
echo "</header>";

echo "<body>";
    echo "<div class='form-accountCenter'>";
        echo "<div class='vr form-accountCenterOptions'>";
            echo "<h1>Account Center</h1>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(ProfileDetails).php'>Profile details</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(PassAndSec).php'>Password and security</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(UserRatings).php'>User ratings</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem form-accCenterOptionPicked'>";
                echo "<a href='accountCenter(Deliveries).php'>Ongoing deliveries</a>";
            echo "</div>";
        echo "</div>";
    
        echo "<div class='form-settingOptions'>";
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            $connection = null;
            
            try{
                $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
                $deliveries = mysqli_execute_query($connection, "SELECT * FROM delivery WHERE vendorID = ?", [$_SESSION["userID"]]);
                    
                if(mysqli_num_rows($deliveries) > 0){
                    while($deliveryDetails = mysqli_fetch_array($deliveries)){
                        echo "<div class='form-deliveryForms'>";
                            $spenderDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM ". $deliveryDetails["userType"] ." WHERE ". $deliveryDetails["userType"] ."ID = ?", [$deliveryDetails["userID"]]));
                            $cartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ?", [$deliveryDetails["deliveryID"]]);
                            echo "<h2>". $spenderDetails["username"] ."</h2>";
                            echo "<h3 class='form-profit'>Total profit: R". $deliveryDetails["totalCost"] ."</h3>";

                            echo "<div class='form-deliveryFormsAddress'>";             
                                echo "<form action='updateDeliveryLocation.php' method='POST'>";
                                    echo "<label for='address'>Delivery address: </label><br>";
                                    echo "<input type='hidden' id='userType' name='userType' value='vendor'>";
                                    echo "<div class='form-deliveryFormsAddressFlex'>";
                                        echo "<input type='text' name='address' id='address' value='". $deliveryDetails["deliveryAddress"] ."'>";
                                        echo "<button type='submit' name='formBtn' id='formBtn' value='". $deliveryDetails["deliveryID"] ."'>Update delivery address</button>";
                                    echo "</div>";
                                echo "</form>";
                                
                                echo "<div class='form-deliveryFormsAddressFlex'>";
                                    echo "<label for='vendorApproval'>Your approval: </label><br>";
                                    if ($deliveryDetails["vendorApproval"] == 0){
                                        echo "<input type='checkbox' name='vendorApproval' id='vendorApproval' disabled>";
                                    }
                                    else{
                                        echo "<input type='checkbox' name='vendorApproval' id='vendorApproval' checked disabled>";
                                    }

                                    echo "<label for='userApproval'>Buyer approval: </label><br>";
                                    if ($deliveryDetails["userApproval"] == 0){
                                        echo "<input type='checkbox' name='userApproval' id='userApproval' disabled>";
                                    }
                                    else{
                                        echo "<input type='checkbox' name='userApproval' id='userApproval' checked disabled>";
                                    }
                                echo "</div><br>";

                                echo "<form action='approveDeliveryLocation.php' method='POST'>";
                                    echo "<input type='hidden' id='userType' name='userType' value='vendor'>";
                                    echo "<input type='hidden' id='currentApproval' name='currentApproval' value='". $deliveryDetails["vendorApproval"] ."'>";
                                    if ($deliveryDetails["vendorApproval"] == 0){
                                        echo "<button type='submit' name='formBtn' id='formBtn' value='". $deliveryDetails["deliveryID"] ."'>Approve delivery address</button>";
                                    }
                                    else{
                                        echo "<button type='submit' name='formBtn' id='formBtn' value='". $deliveryDetails["deliveryID"] ."'>Reject delivery address</button>";
                                    }
                                echo "</form>";
                            echo "</div>";

                            echo "<div class='form-settingOptionsSideItems'>";
                                echo "<form action='deliveryMessages.php' method='POST'>";
                                    echo "<input type='hidden' id='deliveryID' name='deliveryID' value='". $deliveryDetails["deliveryID"] ."'>";
                                    echo "<input type='hidden' id='otherUserID' name='otherUserID' value='". $spenderDetails[$deliveryDetails["userType"] ."ID"] ."'>";
                                    echo "<button type='submit' name='formBtn' id='formBtn' value='vendor'>Chat with customer</button>";
                                echo "</form>";

                                echo "<form action='../deleteRecord.php' method='POST'>";
                                    echo "<input type='hidden' id='userType' name='userType' value='". $_SESSION["userType"] ."'>";
                                    echo "<input type='hidden' id='recordType' name='recordType' value='delivery'>";
                                    echo "<button type='submit' name='formBtn' id='formBtn' value='". $deliveryDetails["deliveryID"] ."'>Cancel order delivery</button>";
                                echo "</form>";
                            echo "</div>";

                            echo "<h2>Delivery items</h2><br>";
                            while($cartItem = mysqli_fetch_array($cartItems)){
                                $productItems = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$cartItem["listingID"]]));
                                
                                echo "<div class='form-listingList'>";
                                    echo "<div class='form-cartLeftItem'>";
                                        echo "<h3>". $productItems["title"] ."</h3>";
                                        echo "<img src='". $productItems["image"] ."' alt='Product.png'>";
                                    echo "</div>";

                                    echo "<div class='form-cartRightItem'>";
                                        echo "<h3 class='form-profit'>Price: R ". $productItems["price"] * $cartItem["quantity"] ."</h3>";
                                        echo "<h4>Quantity: <input type='number' name='quantity' id='quantity' value='". $cartItem["quantity"] ."' min=1 max=". $productItems["inStock"] ." readonly></h4>";
                                    echo "</div>";
                                echo "</div>";
                            }
                        echo "</div>";
                    }
                }
            }
            catch(Exception $error){
                echo "<h2>An error occured</h2>";
            }

            if ($connection != null){
                $connection->close();
            }
            echo "<script src='../script.js'></script>";
        echo "</div>";
    echo "</div>";
echo "</body>";
echo "</html>";
?>