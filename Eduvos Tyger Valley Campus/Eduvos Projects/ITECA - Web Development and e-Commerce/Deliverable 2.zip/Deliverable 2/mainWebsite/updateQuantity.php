<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cartItemID = $_POST["updateBtn"];
    $quantity = $_POST["quantity"];
    $deliveryID = $_POST["deliveryID"];
    $connectionActive = false;
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;
    
    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;
        $cartItem = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE cartItemID = ?", [$cartItemID]));
        $listingDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$cartItem["listingID"]]));

        if ($quantity != null){
            if ($quantity <= 0){
                $_SESSION["message"] = "Error: Invalid quantity";
            }
            else if ($quantity > $listingDetails["inStock"]){
                $_SESSION["message"] = "Error: Quantity exceeds listing's stock";
            }
        }
        else{
            $_SESSION["message"] = "Error: Quantity is required";
        }

        if (empty($errors)) {
            mysqli_execute_query($connection, "Update cartItem SET quantity = $quantity WHERE cartItemID = ?", [$cartItemID]);

            $totalCost = 0;
            $deliveryCartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ?", [$deliveryID]);
            while($deliveryCartItem = mysqli_fetch_array($deliveryCartItems)){
                $listingPrice = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT price FROM listing WHERE listingID = ?", [$deliveryCartItem["listingID"]]));
                $totalCost += ($listingPrice["price"] * $deliveryCartItem["quantity"]);
            }
            mysqli_execute_query($connection, "UPDATE delivery SET totalCost = $totalCost WHERE deliveryID = ?", [$deliveryID]);

            $_SESSION["message"] = "Product's quantity has been updated successfully";
            mysqli_commit($connection);
        }
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

header('Location:cart.php');
?>