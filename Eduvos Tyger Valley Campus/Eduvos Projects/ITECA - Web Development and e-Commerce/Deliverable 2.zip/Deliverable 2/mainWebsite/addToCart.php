<?php
session_start();
$connectionActive = false;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $listingID = $_POST["productBtn"];
    $vendorID = $_POST["vendorID"];
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    if ($listingID >= 0){
        try{
            $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
            mysqli_autocommit($connection, false);
            mysqli_begin_transaction($connection);
            $connectionActive = true;
            $deliveryDetails = null;
            $deliveryExists = mysqli_execute_query($connection, "SELECT * FROM delivery WHERE userType = ? AND userID = ? AND vendorID = ?", [$_SESSION["userType"], $_SESSION["userID"], $vendorID]);

            if (mysqli_num_rows($deliveryExists) > 0){
                $deliveryDetails = mysqli_fetch_array($deliveryExists);
            }
            else{
                mysqli_execute_query($connection, "INSERT INTO delivery (totalCost, deliveryAddress, userApproval, vendorApproval, userType, userID, vendorID) VALUES (0,'',0,0,?,?,?)", [$_SESSION["userType"], $_SESSION["userID"], $vendorID]);
                $deliveryDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM delivery WHERE userType = ? AND userID = ? AND vendorID = ?", [$_SESSION["userType"], $_SESSION["userID"], $vendorID]));
            }
            mysqli_execute_query($connection, "INSERT INTO cartItem (quantity, listingID, deliveryID) VALUES (1, ?, ?)", [$listingID, $deliveryDetails["deliveryID"]]);

            $listingDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$listingID]));
            mysqli_execute_query($connection, "UPDATE delivery SET totalCost = ? WHERE deliveryID = ?", [$deliveryDetails["totalCost"] + $listingDetails["price"], $deliveryDetails["deliveryID"]]);
            $_SESSION["message"] = "Product added to cart successfully";

            mysqli_commit($connection);
        }
        catch(Exception $error){
            $_SESSION["message"] = "Error: ". $error->getMessage();
            if ($connectionActive == true){
                mysqli_rollback($connection);
            }
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

if ($listingID == -1){
    header('Location:cart.php');
}
else if ($listingID == -2){
    header('Location:accountCenter(ProfileDetails).php');
}
else{
    header('Location:index.php');
}
?>