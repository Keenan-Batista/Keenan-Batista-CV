<?php
$success = false;
$connectionActive = false;
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userType = $_POST["userType"];
    $message = $_POST["message"];
    $deliveryID = $_POST["formBtn"];

    $_SESSION["userTypeOrigin"] = $userType;
    $_SESSION["otherUserID"] = $_POST["otherUserID"];
    $_SESSION["deliveryID"] = $deliveryID;
    
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;
    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        mysqli_execute_query($connection, "INSERT INTO deliveryMessage (message, timeSent, userTypeOrigin, deliveryID) VALUES (?,?,?,?)", [$message, date("Y-m-d H:i"), $userType, $deliveryID]);
        mysqli_commit($connection);
        $success = true;
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

if ($success == true){
    header('Location:deliveryMessages.php');
}
else{
    if ($userType == "user"){
        header('Location:cart.php');
    }
    else{
        header('Location:accountCenter(Deliveries).php');
    }
}
?>