<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    $success = true;
    $connectionActive = false;
    $total = $_POST["total"];
    $currentAmount = $_POST["currentAmount"];
    $deliveryID = $_POST["paymentBtn"];
    
    if ($total > $currentAmount){
        $_SESSION["message"] = "You don't have enough funds";
        $success = false;
    }
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    if ($success == true) {
        try{
            $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
            mysqli_autocommit($connection, false);
            mysqli_begin_transaction($connection);
            $connectionActive = true;

            $userDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM ". $_SESSION["userType"] ." WHERE ". $_SESSION["userType"] ."ID = ?", [$_SESSION["userID"]]));
            $deliveryDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM delivery WHERE deliveryID = ?", [$deliveryID]));
            $newWallet = $userDetails["eWalletAmount"] - $total;
            mysqli_execute_query($connection, "UPDATE ". $_SESSION["userType"] ." SET eWalletAmount = ? WHERE $newWallet = ?", [$_SESSION["userType"] ."ID", $_SESSION["userID"]]);
            $cartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ?", [$deliveryID]);

            while($cartItem = mysqli_fetch_array($cartItems)){
                $listingDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$cartItem["listingID"]]));
                $newStock = $listingDetails["inStock"] - $cartItem["quantity"];
                $vendorDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM vendor WHERE vendorID = ?", [$listingDetails["vendorID"]]));
                $newVendorWallet = $vendorDetails["eWalletAmount"] + ($listingDetails["price"] * $cartItem["quantity"]);
                mysqli_execute_query($connection, "UPDATE listing SET inStock = ? WHERE listingID = ?", [$newStock, $cartItem["listingID"]]);
                mysqli_execute_query($connection, "UPDATE vendor SET eWalletAmount = ? WHERE vendorID = ?", [$newVendorWallet, $vendorDetails["vendorID"]]);
            }

            mysqli_execute_query($connection, "Delete FROM cartItem WHERE deliveryID = ?", [$deliveryID]);
            mysqli_execute_query($connection, "Delete FROM delivery WHERE deliveryID = ?", [$deliveryID]);
            mysqli_execute_query($connection, "Delete FROM deliveryMessage WHERE deliveryID = ?", [$deliveryID]);
            $ratingHistory = mysqli_execute_query($connection, "SELECT * FROM userRatingHistory WHERE userType = ? AND userID = ? AND vendorID = ?", [$deliveryDetails["userType"], $deliveryDetails["userID"], $deliveryDetails["vendorID"]]);
            if (mysqli_num_rows($ratingHistory) <= 0){
                mysqli_execute_query($connection, "INSERT INTO userRatingHistory (rated, ratingAmount, ratingType, userType, userID, vendorID) VALUES (0, 0, 'buyer', ?, ?, ?)", [$deliveryDetails["userType"], $deliveryDetails["userID"], $deliveryDetails["vendorID"]]);
                mysqli_execute_query($connection, "INSERT INTO userRatingHistory (rated, ratingAmount, ratingType, userType, userID, vendorID) VALUES (0, 0, 'vendor', ?, ?, ?)", [$deliveryDetails["userType"], $deliveryDetails["userID"], $deliveryDetails["vendorID"]]);   
            }

            $_SESSION["message"] = "Purchase was successful";
            mysqli_commit($connection);
        }
        catch(Exception $error){
            $_SESSION["message"] = "Error: ". $error->getMessage();
            if ($connectionActive == true){
                mysqli_rollback($connection);
            }
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

header('Location:cart.php');
?>