<?php
session_start();
$success = true;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fundInc = $_POST["fundInc"];
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;
    $connectionActive = false;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        if (empty($fundInc)){
            $_SESSION["message"] = "Voucher amount is required";
            $success = false;
        }
        else if ($fundInc < 25 || $fundInc > 10000){
            $_SESSION["message"] = "Invalid voucher amount! The voucher amount can only be between R25 and R10000";
            $success = false;
        }

        if ($success == true) {
            $userDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM ". $_SESSION["userType"] ." WHERE ". $_SESSION["userType"] ."ID = ?", [$_SESSION["userID"]]));
            $totalMoney = $userDetails["eWalletAmount"] + $fundInc;
            mysqli_execute_query($connection, "UPDATE ". $_SESSION["userType"] ." SET eWalletAmount = ? WHERE ". $_SESSION["userType"] ."ID = ?", [$totalMoney, $_SESSION["userID"]]);

            $_SESSION["message"] = "Voucher redeemed successfully";
            mysqli_commit($connection); 
        }
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

header('Location:cart.php');
?>