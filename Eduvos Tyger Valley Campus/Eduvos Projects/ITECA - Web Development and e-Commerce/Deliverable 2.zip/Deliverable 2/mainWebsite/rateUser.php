<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userType = $_POST["userType"];
    $rating = $_POST["rating"];
    $ratingType = $_POST["ratingType"];
    $userID = $_POST["formBtn"];
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;
    $connectionActive = false;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $totalRating = 0;
        $newRating = 0;
        $allRatings = null;

        if ($ratingType == "buyer"){
            mysqli_execute_query($connection, "UPDATE userRatingHistory SET ratingAmount = ? WHERE userID = ? AND ratingType = 'buyer'", [$rating, $userID]);
            mysqli_execute_query($connection, "UPDATE userRatingHistory SET rated = 1 WHERE userID = ? AND ratingType = 'buyer'", [$userID]);
            $allRatings = mysqli_execute_query($connection, "SELECT * FROM userRatingHistory WHERE userID = ? AND rated = '1'", [$userID]);
        }
        else{
            mysqli_execute_query($connection, "UPDATE userRatingHistory SET ratingAmount = ? WHERE vendorID = ? AND ratingType = 'vendor'", [$rating, $userID]);
            mysqli_execute_query($connection, "UPDATE userRatingHistory SET rated = 1 WHERE vendorID = ? AND ratingType = 'vendor'", [$userID]);
            $allRatings = mysqli_execute_query($connection, "SELECT * FROM userRatingHistory WHERE vendorID = ? AND rated = '1'", [$userID]);
        }

        while($ratingNum = mysqli_fetch_array($allRatings)){
            $totalRating += $ratingNum["ratingAmount"];
        }
        $newRating = $totalRating / mysqli_num_rows($allRatings);
        mysqli_execute_query($connection, "Update $userType SET ". $ratingType ."Rating = ? WHERE $newRating = ?", [$userType ."ID", $userID]);

        $_SESSION["message"] = "User rated successfully";
        mysqli_commit($connection);
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

header('Location:accountCenter(UserRatings).php');
?>