<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cartItemID = $_POST["removeBtn"];
    $deliveryID = $_POST["deliveryID"];
    $connectionActive = false;
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;
    
    try {
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $cartItem = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE cartItemID = ?", [$cartItemID]));       
        mysqli_execute_query($connection, "Delete FROM cartItem WHERE cartItemID = ?", [$cartItemID]);

        $deliveryCartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ?", [$deliveryID]);
        if (mysqli_num_rows($deliveryCartItems) <= 0){
            mysqli_execute_query($connection, "DELETE FROM delivery WHERE deliveryID = ?", [$deliveryID]);
            mysqli_execute_query($connection, "DELETE FROM deliveryMessage WHERE deliveryID = ?", [$deliveryID]);
        }
        else{
            $deliveryDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM delivery WHERE deliveryID = ?", [$deliveryID]));
            $listingDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$cartItem["listingID"]]));
            mysqli_execute_query($connection, "UPDATE delivery SET totalCost = ? WHERE deliveryID = ?", [($deliveryDetails["totalCost"] - ($listingDetails["price"] * $cartItem["quantity"])), $deliveryID]);
        }

        $_SESSION["message"] = "Product removed from cart successfully";
        mysqli_commit($connection);
    } 
    catch(Exception $error) {
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

header('Location:cart.php');
?>