<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $connectionActive = false;
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $userDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM buyer WHERE buyerID = ?", [$_SESSION["userID"]]));
        mysqli_execute_query($connection, "INSERT INTO vendor (firstName, lastName, username, phoneNum, email, address, password, buyerRating, eWalletAmount, vendorRating, notify) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)", [$userDetails["firstName"], $userDetails["lastName"], $userDetails["username"], $userDetails["phoneNum"], $userDetails["email"], $userDetails["address"], $userDetails["password"], $userDetails["buyerRating"], $userDetails["eWalletAmount"], $userDetails["notify"]]);
        $vendorDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT vendorID FROM vendor WHERE username = ?", [$_SESSION["username"]]));

        mysqli_execute_query($connection, "Update delivery SET userID = ? WHERE userID = ? AND userType = 'buyer'", [$vendorDetails["vendorID"], $userDetails["buyerID"]]);
        mysqli_execute_query($connection, "Update delivery SET userType = 'vendor' WHERE userID = ? AND userType = 'buyer'", [$vendorDetails["vendorID"]]);
        mysqli_execute_query($connection, "Update userRatingHistory SET userID = ? WHERE userID = ?", [$vendorDetails["vendorID"], $userDetails["buyerID"]]);
        mysqli_execute_query($connection, "Update userRatingHistory SET userType = 'vendor' WHERE userID = ?", [$vendorDetails["vendorID"]]);
        mysqli_execute_query($connection, "Delete FROM buyer WHERE buyerID = ?", [$userDetails["buyerID"]]);

        $_SESSION["message"] = "Account registered as a vendor successfully";
        mysqli_commit($connection);
        $_SESSION["userID"] = $vendorDetails["vendorID"];
        $_SESSION["userType"] = "vendor";
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
}
else{
    $_SESSION["message"] = "Error: POST error occured";
}

header('Location:index.php');
?>