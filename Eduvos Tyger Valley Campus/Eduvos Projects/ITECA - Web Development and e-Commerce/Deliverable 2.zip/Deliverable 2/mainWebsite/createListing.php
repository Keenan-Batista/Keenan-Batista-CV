<?php
session_start();
echo "<link rel='stylesheet' href='../style.css'>";
echo "<div class='form-accountDetails'>";
$success = false;
$connectionActive = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $title = $_POST["title"];
        $price = $_POST["price"];
        $inStock = $_POST["inStock"];
        $description = $_POST["description"];
        $category = $_POST["productCategories"];
        $picDir = "../images/";
        $picName = basename($_FILES["productVisual"]["name"]);
        $picFilePath = $picDir . $picName;
        $errors = [];

        if (empty($title)) {
            $errors[] = "Username is required";
        }
        if (empty($price)) {
            $errors[] = "Price is required";
        }
        else if ($price < 0){
            $errors[] = "Price can't be negative";
        }

        if (empty($inStock)) {
            $errors[] = "Stock is required";
        }
        else if ($inStock < 1){
            $errors[] = "Stock can't be negative or zero";
        }

        if (empty($errors)) {
            $fileNameFound = false;
            $newFileName = $picFilePath;
            $extraCharacters = "";
            $loopNum = 0;

            do{
                if ($extraCharacters != ""){
                    $characterParts = explode('.', $picFilePath);
                    $extension = $characterParts[count($characterParts) - 1];
                    array_pop($characterParts);
                    $newFileName = implode('.', $characterParts) . $extraCharacters  . "." . $extension;
                }

                if (file_exists($newFileName)){
                    $fileNameFound = true;
                    $loopNum++;
                    $extraCharacters = "(". $loopNum .")";
                }
                else{
                    $fileNameFound = false;
                    $picFilePath = $newFileName;
                }
            } while($fileNameFound == true);

            mysqli_execute_query($connection, "INSERT INTO listing (title, price, description, inStock, category, image, vendorID) VALUES (?, ?, ?, ?, ?, ?, ?)", [$title, $price, $description, $inStock, $category, $picFilePath, $_SESSION["userID"]]);
            $_SESSION["message"] = "Listing hosted successfully";
            $success = true;

            mysqli_commit($connection);
            move_uploaded_file($_FILES["productVisual"]["tmp_name"], $picFilePath);
        } else {
            echo "<h1>Listing error</h1>";
            echo "<h3>Listing couldn't be registered due to the following error(s):</h3>";
            echo "<div class='form-errorBoard error'>";
            foreach ($errors as $error) {
                echo "<h4>*$error</h4>";
            }
            echo "</div>";
            echo "<a href='createListing.html' class='form-returnLink'>Return to listing</a>";
        }
    }
    catch(Exception $error){
        echo "<h1>Listing error</h1>";
        echo "<h3>Listing couldn't be registered due to the following error(s):</h3>";
        echo "<div class='form-errorBoard error'>";
            echo "<h4>*Error: ". $error->getMessage() ."</h4>";
        echo "</div>";
        echo "<a href='createListing.html' class='form-returnLink'>Return to listing</a>";

        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $success = true;
    $_SESSION["message"] = "Error: POST error occured";
}
echo "</div>";

if ($success == true){
    header('Location:index.php');
}
?>