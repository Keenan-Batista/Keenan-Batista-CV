<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userType = $_POST["userType"];
    $address = $_POST["address"];
    $deliveryID = $_POST["formBtn"];
    $connectionActive = false;
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;
    
    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        mysqli_execute_query($connection, "UPDATE delivery SET deliveryAddress = ? WHERE deliveryID = ?", [$address, $deliveryID]);
        mysqli_execute_query($connection, "UPDATE delivery SET userApproval = 0 WHERE deliveryID = ?", [$deliveryID]);
        mysqli_execute_query($connection, "UPDATE delivery SET vendorApproval = 0 WHERE deliveryID = ?", [$deliveryID]);
        $_SESSION["message"] = "Delivery address has been updated successfully";
        mysqli_commit($connection);
    }
    catch(Exception $error){
        $_SESSION["message"] = "Error: ". $error->getMessage();
        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}

if ($userType == "user"){
    header('Location:cart.php');
}
else{
    header('Location:accountCenter(Deliveries).php');
}
?>