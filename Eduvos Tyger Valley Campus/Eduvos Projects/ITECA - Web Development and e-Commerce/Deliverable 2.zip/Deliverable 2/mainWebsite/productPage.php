<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $listingID = $_POST["formBtn"];
    echo "<html lang='en'>";
    echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
        echo "<title>Marketplace</title>";
        echo "<link rel='stylesheet' href='../style.css'>";
    echo "</head>";

    echo "<header>";
        echo "<h1><a href='index.php'>Marketplace</a></h1>";
        echo "<div class='form-mainHeading'>";
            echo "<div class='form-account'>";
                echo "<a href='index.php'>Return to the store front</a>";
            echo "</div>";
        echo "</div>";
    echo "</header>";
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        echo "<body>";
        $listingCategory = null;
        echo "<div class='form-productPage'>";
            if ($listingDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM listing WHERE listingID = ?", [$listingID]))){
                $listingCategory = $listingDetails["category"];
                $vendorDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM vendor WHERE vendorID = ?", [$listingDetails["vendorID"]]));

                echo "<div class='form-productPageLeft vr'>";
                    echo "<img src='". $listingDetails["image"] ."' alt='Product.png'>";
                echo "</div><hr>";

                echo "<div class='form-productPageRight'>";
                    echo "<div class='form-productPageMainHeading'>";
                        echo "<h1>". $listingDetails["title"] ."</h1>";
                        echo "<div class='form-productsGridVendor'>";
                            echo "<h2>". $vendorDetails["username"] ."</h2>";
                            echo "<h3>". $vendorDetails["vendorRating"] ." vendor rating</h3>";
                        echo "</div>";
                    echo "</div>";

                    echo "<h3 class='form-cost'>R". $listingDetails["price"] ."</h3>";
                    echo "<h3>". $listingDetails["inStock"] ." left in stock</h3><br>";
                    echo "<h3>Description</h3>";
                    echo "<p>". $listingDetails["description"] ."</p><br>";

                    echo "<form action='addToCart.php' method='POST'>";
                        if (isset($_SESSION["userID"])){
                            $deliveryDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM delivery WHERE userType = ? AND userID = ? AND vendorID = ?", [$_SESSION["userType"], $_SESSION["userID"], $listingDetails["vendorID"]]));
                            if ($listingDetails["vendorID"] == $_SESSION["userID"] && $_SESSION["userType"] == 'vendor'){
                                echo "<button name='productBtn' id='productBtn' value='-2'>Your listing</button>";
                            }
                            else{
                                if (!isset($deliveryDetails["deliveryID"])){
                                    echo "<input type='hidden' name='vendorID' id='vendorID' value='". $listingDetails["vendorID"] ."'>";
                                    echo "<button type='submit' name='productBtn' id='productBtn' value='". $listingDetails["listingID"] ."'>Add to cart</button>";
                                }
                                else{
                                    if ($cartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ? AND listingID = ?", [$deliveryDetails["deliveryID"], $listingDetails["listingID"]])){
                                        if(mysqli_num_rows($cartItems) <= 0){
                                            echo "<input type='hidden' name='vendorID' id='vendorID' value='". $listingDetails["vendorID"] ."'>";
                                            echo "<button type='submit' name='productBtn' id='productBtn' value='". $listingDetails["listingID"] ."'>Add to cart</button>";
                                        }
                                        else{
                                            echo "<button type='submit' name='productBtn' id='productBtn' value='-1'>In cart</button>";
                                        }
                                    }
                                }
                            }
                        }
                        else{
                            echo "<button disabled>Add to cart</button>";
                        }
                    echo "</form>";
                echo "</div>";
            }
        echo "</div>";

        if ($relatedRecords = mysqli_execute_query($connection, "SELECT * FROM listing WHERE category = ? AND NOT listingID = ?", [$listingCategory, $listingID])){
            if(mysqli_num_rows($relatedRecords) > 0){
                echo "<h1 class='form-moveLeft'>Products in the same category</h1>";
                echo "<div class='form-productsGridContainer'>";
                    while($recordDetails = mysqli_fetch_array($relatedRecords)){
                        $vendorDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM vendor WHERE vendorID = ?", [$recordDetails["vendorID"]]));
                        echo "<div class='form-productsGridItem'>";
                            echo "<div class='form-productsGridItemImage'>";
                                echo "<form action='productPage.php' method='POST'>";
                                    echo "<button type='submit' id='formBtn' name='formBtn' value='". $recordDetails["listingID"] ."'><img src='". $recordDetails["image"] ."' alt='Product.png'></button>";
                                echo "</form>";
                            echo "</div>";

                            echo "<div class='form-productsGridVendor'>";
                                echo "<h2>". $vendorDetails["username"] ."</h2>";
                                echo "<h3>". $vendorDetails["vendorRating"] ."</h3>";
                            echo "</div>";

                            echo "<h3>". $recordDetails["title"] ."</h3>";
                            echo "<h4 class='form-cost'>R ". $recordDetails["price"] ."</h4>";
                            echo "<h4>". $recordDetails["category"] ."</h4>";

                            echo "<form action='addToCart.php' method='POST'>";
                                if (isset($_SESSION["userID"])){
                                    $deliveryDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM delivery WHERE userType = ? AND userID = ? AND vendorID = ?", [$_SESSION["userType"], $_SESSION["userID"], $recordDetails["vendorID"]]));
                                    if ($recordDetails["vendorID"] == $_SESSION["userID"] && $_SESSION["userType"] == 'vendor'){
                                        echo "<button name='productBtn' id='productBtn' value='-2'>Your listing</button>";
                                    }
                                    else{
                                        if (!isset($deliveryDetails["deliveryID"])){
                                            echo "<input type='hidden' name='vendorID' id='vendorID' value='". $recordDetails["vendorID"] ."'>";
                                            echo "<button type='submit' name='productBtn' id='productBtn' value='". $recordDetails["listingID"] ."'>Add to cart</button>";
                                        }
                                        else{
                                            if ($cartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ? AND listingID = ?", [$deliveryDetails["deliveryID"], $recordDetails["listingID"]])){
                                                if(mysqli_num_rows($cartItems) <= 0){
                                                    echo "<input type='hidden' name='vendorID' id='vendorID' value='". $recordDetails["vendorID"] ."'>";
                                                    echo "<button type='submit' name='productBtn' id='productBtn' value='". $recordDetails["listingID"] ."'>Add to cart</button>";
                                                }
                                                else{
                                                    echo "<button type='submit' name='productBtn' id='productBtn' value='-1'>In cart</button>";
                                                }
                                            }
                                        }
                                    }
                                }
                                else{
                                    echo "<button disabled>Add to cart</button>";
                                }
                            echo "</form>";
                        echo "</div>";
                    }
                echo "</div>";
            }
        }
        echo "</body>";
    }
    catch(Exception $error){
        echo "<h2>An error occurred</h2>";
    }

    echo "</html>";
}
else{
    echo "<h1>An error occurred</h1>";
}
?>