<?php
echo "<link rel='stylesheet' href='../style.css'>";
echo "<div class='form-accountDetails'>";
$success = false;
$connectionActive = false;
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try {
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $firstName = $_POST["fName"];
        $lastName = $_POST["lName"];
        $username = $_POST["username"];
        $phoneNum = $_POST["phoneNum"];
        $email = $_POST["email"];
        $address = $_POST["address"];
        $password = $_POST["password"];
        $conPassword = $_POST["conPassword"];
        $notify = isset($_POST["notify"]);
        $userAgreement = isset($_POST["userAgreement"]);

        $errors = [];

        if (empty($firstName)) {
            $errors[] = "First name is required";
        }
        if (empty($lastName)) {
            $errors[] = "Last name is required";
        }
        if (empty($username)) {
            $errors[] = "Username is required";
        }
        else{
            $sqlUsernameB = mysqli_execute_query($connection, "SELECT username FROM buyer WHERE username = ?", [$username]);
            if (mysqli_num_rows($sqlUsernameB) > 0){
                $errors[] = "Username already exists";
            }
            else{
                $sqlUsernameV = mysqli_execute_query($connection, "SELECT username FROM vendor WHERE username = ?", [$username]);
                if (mysqli_num_rows($sqlUsernameV) > 0){
                    $errors[] = "Username already exists";
                }
                else{
                    $sqlUsernameA = mysqli_execute_query($connection, "SELECT username FROM admin WHERE username = ?", [$username]);
                    if (mysqli_num_rows($sqlUsernameA) > 0){
                        $errors[] = "Username already exists";
                    }
                }
            }
        }

        if (empty($phoneNum)) {
            $errors[] = "Phone number is required";
        }

        if (empty($email)) {
            $errors[] = "Email is required";
        } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email";
        }

        if (empty($address)) {
            $errors[] = "Address is required";
        }

        if (empty($password)) {
            $errors[] = "Password is required";
        } else if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 or more characters in length";
        }

        if (empty($conPassword)) {
            $errors[] = "Password must be repeated for confirmation";
        } else if ($password != $conPassword) {
            $errors[] = "Password and confirmation password don't match";
        }

        if (empty($userAgreement)) {
            $errors[] = "You must agree to the user agreement and privacy policy if you wish to use the marketplace";
        }

        if (empty($errors)) {
            $notifyChecked = 0;
            if (!empty($notify)){
                $notifyChecked = 1;
            }
            mysqli_execute_query($connection, "INSERT INTO buyer (firstName, lastName, username, phoneNum, email, address, password, buyerRating, eWalletAmount, notify) VALUES (?, ?, ?, ?, ?, ?, ?, '0', '0', ?)", [$firstName, $lastName, $username, $phoneNum, $email, $address, password_hash($password, PASSWORD_DEFAULT), $notifyChecked]);
            $userDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT buyerID FROM buyer WHERE username = ?", [$username]));

            mysqli_commit($connection);
            $success = true;
            $_SESSION["message"] = "Account registered successfully";
            $_SESSION["userID"] = $userDetails["buyerID"];
            $_SESSION["firstName"] = $firstName;
            $_SESSION["lastName"] = $lastName;
            $_SESSION["username"] = $username;
            $_SESSION["phoneNum"] = $phoneNum;
            $_SESSION["email"] = $email;
            $_SESSION["address"] = $address;
            $_SESSION["userType"] = "buyer"; 
        } else {
            echo "<h1>Account registration error</h1>";
            echo "<h3>Account couldn't be registered due to the following error(s):</h3>";
            echo "<div class='form-errorBoard error'>";
                foreach ($errors as $error) {
                    echo "<h4>$error</h4>";
                }
            echo "</div>";
            echo "<a href='accountRegistration.html' class='form-returnLink'>Return to registration page</a>";
        }
    }
    catch(Exception $error){
        echo "<h1>Account registration error</h1>";
        echo "<h3>Account couldn't be registered due to the following error(s):</h3>";
        echo "<div class='form-errorBoard error'>";
            echo "<h4>Error: ". $error->getMessage() ."</h4>";
        echo "</div>";
        echo "<a href='accountRegistration.html' class='form-returnLink'>Return to registration page</a>";

        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }
    
    if ($connection != null){
        $connection->close();
    }
} else {
    $success = true;
    $_SESSION["message"] = "Error: POST error occured";
}
echo "</div>";

if ($success == true){
    header('Location:index.php');
}
?>