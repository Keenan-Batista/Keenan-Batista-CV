<?php
session_start();
if (!isset($_SESSION["userID"]) && empty($_SESSION["userID"])){
    header('Location:index.php');
}

$username = $_SESSION["username"];
$firstName = $_SESSION["firstName"];
$lastName = $_SESSION["lastName"];
$phoneNum = $_SESSION["phoneNum"];
$email = $_SESSION["email"];
$address = $_SESSION["address"];

echo "<html lang='en'>";
echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>My Account</title>";
    echo "<link rel='stylesheet' href='../style.css'>";
echo "</head>";

if (isset($_SESSION["message"]) && !empty($_SESSION["message"])){
    echo "<div id='message' name='message' class='msg'>";
        echo "<p>". $_SESSION["message"] ."</p>";
        echo "<button onclick='closeMessage()'>X</button>";
    echo "</div>";
    unset($_SESSION["message"]);
    echo "<script src='../script.js'></script>";
}

echo "<header>";
    echo "<h1><a href='index.php'>Marketplace</a></h1>";
    echo "<div class='form-mainHeading'>";
        echo "<div class='form-account'>";
            echo "<a href='index.php'>Return to the store front</a>";
        echo "</div>";
    echo "</div>";
echo "</header>";

echo "<body>";
    echo "<div class='form-accountCenter'>";
        echo "<div class='form-accountCenterOptions'>";
            echo "<h1 >Account Center</h1>";
            echo "<div class='form-accountCenterOptionsItem form-accCenterOptionPicked'>";
                echo "<a href='accountCenter(ProfileDetails).php'>Profile details</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(PassAndSec).php'>Password and security</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='accountCenter(UserRatings).php'>User ratings</a>";
            echo "</div>";

            if ($_SESSION["userType"] == "vendor"){
                echo "<div class='form-accountCenterOptionsItem'>";
                    echo "<a href='accountCenter(Deliveries).php'>Ongoing deliveries</a>";
                echo "</div>";
            }
        echo "</div>";

        echo "<div class='form-settingOptions'>";
            echo "<div class='form-settingOptionsSideItems'>";
                echo "<div class='form-inputDetails'>";
                    echo "<label for='username'>Current username:</label><br>";
                    echo "<input type='text' name='username' id='username' value='$username' readonly>";
                echo "</div>";

                echo "<div class='form-inputDetails'>";
                    echo "<form action='../accountLogOut.php' method='POST'>";
                        echo "<button>Log out</button>";
                    echo "</form>";
                echo "</div>";
            echo "</div>";

            echo "<div class='form-settingOptionsItem'>";
                echo "<div class='form-inputDetails'>";
                    echo "<label for='fName'>First name: </label><br>";
                    echo "<input type='text' name='fName' id='fName' value='$firstName' readonly>";
                echo "</div>";
                echo "<div class='form-inputDetails'>";
                    echo "<label for='lName'>Last name: </label><br>";
                    echo "<input type='text' name='lName' id='lName' value='$lastName' readonly>";
                echo "</div>";
            echo "</div>";

            echo "<div class='form-settingOptionsItem'>";
                echo "<div class='form-inputDetails'>";
                    echo "<label for='phoneNum'>Phone number: </label><br>";
                    echo "<input type='tel' name='phoneNum' id='phoneNum' value='$phoneNum' readonly>";
                echo "</div>";

                echo "<div class='form-inputDetails'>";
                    echo "<label for='email'>Email: </label><br>";
                    echo "<input type='email' name='email' id='email' value='$email' readonly>";
                echo "</div>";
            echo "</div>";

            echo "<div class='form-settingOptionsItem'>";
                echo "<div class='form-longInputDetails'>";
                    echo "<label for='address'>Address: </label><br>";
                    echo "<input type='text' name='address' id='address' value='$address' readonly>";
                echo "</div>";
            echo "</div>";

            if ($_SESSION["userType"] == "buyer"){
                echo "<div class='form-settingOptionsItem'>";
                    echo "<div class='form-inputDetails'>";
                        echo "<form action='vendorRegistration.php' method='POST'>";
                            echo "<button>Become a vendor</button>";
                        echo "</form>";
                    echo "</div>";
                echo "</div>";
            }
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            $connection = null;

            try{
                $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
                $listingItems = mysqli_execute_query($connection, "SELECT * FROM listing WHERE vendorID = ?", [$_SESSION["userID"]]);

                if(mysqli_num_rows($listingItems) > 0){
                    echo "<h1>Current listings</h1>";
                    while($recordDetails = mysqli_fetch_array($listingItems)){
                        echo "<div class='form-listingList'>";
                            echo "<div class='form-cartLeftItem'>";
                                echo "<h2>". $recordDetails["title"] ."</h2>";
                                echo "<img src='". $recordDetails["image"] ."' alt='Product.png'>";
                            echo "</div>";

                            echo "<div class='form-cartRightItem'>";
                                echo "<h3>Price: R ". $recordDetails["price"] ."</h3>";
                                echo "<form action='updateStock.php' method='POST'>";
                                    echo "<h4>Stock: <input type='number' name='stock' id='stock' value='". $recordDetails["inStock"] ."' min=0></h4>";
                                    echo "<button type='submit' name='updateBtn' id='updateBtn' value='". $recordDetails["listingID"] ."'>Update stock</button>";
                                echo "</form>";

                                echo "<form action='../deleteRecord.php' method='POST'>";
                                    echo "<input type='hidden' value='listing' name='recordType' id='recordType'>";
                                    echo "<button type='submit' name='formBtn' id='formBtn' value='". $recordDetails["listingID"] ."'>Remove listing</button>";
                                echo "</form>";
                            echo "</div>";
                        echo "</div>";
                    }
                }
            }
            catch(Exception $error){
                echo "<h2>An error occured</h2>";
            }

            if ($connection != null){
                $connection->close();
            }
        echo "</div>";
    echo "</div>";
echo "</body>";
echo "</html>";
?>