const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

function validateRegistration() {
    let valid = true;
    const fName = document.getElementById("fName").value.trim();
    const lName = document.getElementById("lName").value.trim();
    const username = document.getElementById("username").value.trim();
    const phoneNum = document.getElementById("phoneNum").value.trim();
    const email = document.getElementById("email").value.trim();
    const address = document.getElementById("address").value.trim();
    const password = document.getElementById("password").value.trim();
    const conPassword = document.getElementById("conPassword").value.trim();
    const userAgreement = document.getElementById("userAgreement").checked;

    document.querySelectorAll(".error").forEach(
        function (message) {
            message.textContent = "";
        }
    )

    if (fName === "") {
        document.getElementById("fNameError").textContent = "First name is required";
        valid = false;
    }
    if (lName === "") {
        document.getElementById("lNameError").textContent = "Last name is required";
        valid = false;
    }
    if (username === "") {
        document.getElementById("usernameError").textContent = "Username is required";
        valid = false;
    }
    if (phoneNum === "") {
        document.getElementById("phoneNumError").textContent = "Phone number is required";
        valid = false;
    }
    if (email === "") {
        document.getElementById("emailError").textContent = "Email is required";
        valid = false;
    }
    else if (!emailPattern.test(email)) {
        document.getElementById("emailError").textContent = "Email is invalid";
        valid = false;
    }
    if (address === "") {
        document.getElementById("addressError").textContent = "Address is required";
        valid = false;
    }

    if (password === "") {
        document.getElementById("passwordError").textContent = "Password is required";
        valid = false;
    }
    else if (password.length < 8) {
        document.getElementById("passwordError").textContent = "Password must be at least 8 characters or more in length";
        valid = false;
    }
    if (conPassword === "") {
        document.getElementById("conPasswordError").textContent = "Password must be repeated for confirmation";
        valid = false;
    }
    else if (password !== conPassword) {
        document.getElementById("conPasswordError").textContent = "Password and confirmation password don't match";
        valid = false;
    }

    if (userAgreement == false) {
        document.getElementById("userAgreementError").textContent = "You must agree to the user agreement and privacy policy if you wish to use the marketplace";
        valid = false;
    }

    return valid;
}

function validateLogin(){
    let valid = true;
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    document.querySelectorAll(".error").forEach(
        function (message) {
            message.textContent = "";
        }
    )

    if (username === "") {
        document.getElementById("usernameError").textContent = "Username is required";
        valid = false;
    }
    if (password === "") {
        document.getElementById("passwordError").textContent = "Password is required";
        valid = false;
    }

    return valid;
}

function validatePasswords(){
    let valid = true;
    const password = document.getElementById("password").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();
    const conPassword = document.getElementById("conPassword").value.trim();

    document.querySelectorAll(".error").forEach(
        function (message) {
            message.textContent = "";
        }
    )

    if (password === "") {
        document.getElementById("passwordError").textContent = "Password is required";
        valid = false;
    }

    if (newPassword === "") {
        document.getElementById("newPasswordError").textContent = "New password is required";
        valid = false;
    }
    else if (newPassword.length < 8) {
        document.getElementById("newPasswordError").textContent = "New password must be at least 8 characters or more in length";
        valid = false;
    }

    if (conPassword === "") {
        document.getElementById("conPasswordError").textContent = "Password must be repeated for confirmation";
        valid = false;
    }
    else if (newPassword !== conPassword) {
        document.getElementById("conPasswordError").textContent = "New password and confirmation password don't match";
        valid = false;
    }

    return valid;
}

function validateListing(){
    let valid = true;
    const title = document.getElementById("title").value.trim();
    const price = document.getElementById("price").value.trim();
    const stock = document.getElementById("inStock").value.trim();
    const productVisual = document.getElementById("productVisual").files;

    document.querySelectorAll(".error").forEach(
        function (message) {
            message.textContent = "";
        }
    )

    if (title === "") {
        document.getElementById("titleError").textContent = "Title is required";
        valid = false;
    }
    
    if (price === "") {
        document.getElementById("priceError").textContent = "Price is required";
        valid = false;
    }
    else if(price < 0){
        document.getElementById("priceError").textContent = "Price can't be negative";
        valid = false;
    }

    if (stock === "") {
        document.getElementById("stockError").textContent = "Stock is required";
        valid = false;
    }
    else if(stock < 1){
        document.getElementById("stockError").textContent = "Invalid stock";
        valid = false;
    }

    if (productVisual.length === 0) {
        document.getElementById("imageError").textContent = "Product image is required";
        valid = false;
    }

    return valid;
}

function validateVoucher(){
    let valid = true;
    const fundInc = document.getElementById("fundInc").value.trim();

    document.querySelectorAll(".error").forEach(
        function (message) {
            message.textContent = "";
        }
    )

    if (fundInc === "") {
        document.getElementById("fundError").textContent = "Voucher amount is required";
        valid = false;
    }
    else if(fundInc < 25 || fundInc > 10000){
        document.getElementById("fundError").textContent = "Invalid voucher amount! The voucher amount can only be between R25 and R10000";
        valid = false;
    }
    return valid;
}

function validateAdminCreation() {
    let valid = true;
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const conPassword = document.getElementById("conPassword").value.trim();

    document.querySelectorAll(".error").forEach(
        function (message) {
            message.textContent = "";
        }
    )

    if (username === "") {
        document.getElementById("usernameError").textContent = "Username is required";
        valid = false;
    }

    if (password === "") {
        document.getElementById("passwordError").textContent = "Password is required";
        valid = false;
    }
    else if (password.length < 8) {
        document.getElementById("passwordError").textContent = "Password must be at least 8 characters or more in length";
        valid = false;
    }

    if (conPassword === "") {
        document.getElementById("conPasswordError").textContent = "Password must be repeated for confirmation";
        valid = false;
    }
    else if (password !== conPassword) {
        document.getElementById("conPasswordError").textContent = "Password and confirmation password don't match";
        valid = false;
    }

    return valid;
}

function validateUserCreation(){
    let valid = true;
    const fName = document.getElementById("fName").value.trim();
    const lName = document.getElementById("lName").value.trim();
    const username = document.getElementById("username").value.trim();
    const phoneNum = document.getElementById("phoneNum").value.trim();
    const email = document.getElementById("email").value.trim();
    const address = document.getElementById("address").value.trim();
    const password = document.getElementById("password").value.trim();
    const conPassword = document.getElementById("conPassword").value.trim();

    document.querySelectorAll(".error").forEach(
        function (message) {
            message.textContent = "";
        }
    )

    if (fName === "") {
        document.getElementById("fNameError").textContent = "First name is required";
        valid = false;
    }
    if (lName === "") {
        document.getElementById("lNameError").textContent = "Last name is required";
        valid = false;
    }
    if (username === "") {
        document.getElementById("usernameError").textContent = "Username is required";
        valid = false;
    }
    if (phoneNum === "") {
        document.getElementById("phoneNumError").textContent = "Phone number is required";
        valid = false;
    }
    if (email === "") {
        document.getElementById("emailError").textContent = "Email is required";
        valid = false;
    }
    else if (!emailPattern.test(email)) {
        document.getElementById("emailError").textContent = "Email is invalid";
        valid = false;
    }
    if (address === "") {
        document.getElementById("addressError").textContent = "Address is required";
        valid = false;
    }

    if (password === "") {
        document.getElementById("passwordError").textContent = "Password is required";
        valid = false;
    }
    else if (password.length < 8) {
        document.getElementById("passwordError").textContent = "Password must be at least 8 characters or more in length";
        valid = false;
    }
    if (conPassword === "") {
        document.getElementById("conPasswordError").textContent = "Password must be repeated for confirmation";
        valid = false;
    }
    else if (password !== conPassword) {
        document.getElementById("conPasswordError").textContent = "Password and confirmation password don't match";
        valid = false;
    }

    return valid;
}

function closeMessage(){
    let msg = document.getElementById("message");
    msg.classList.remove("msg");
    msg.classList.add("hide");
}