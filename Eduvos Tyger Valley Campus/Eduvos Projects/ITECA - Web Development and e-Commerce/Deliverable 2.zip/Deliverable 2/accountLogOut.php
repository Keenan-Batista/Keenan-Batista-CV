<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    unset($_SESSION["userID"]);
    unset($_SESSION["firstName"]);
    unset($_SESSION["lastName"]);
    unset($_SESSION["username"]);
    unset($_SESSION["phoneNum"]);
    unset($_SESSION["email"]);
    unset($_SESSION["address"]);
    unset($_SESSION["userType"]);
    $_SESSION["message"] = "Successfully logged out of account";
}

header('Location:index.php');
?>