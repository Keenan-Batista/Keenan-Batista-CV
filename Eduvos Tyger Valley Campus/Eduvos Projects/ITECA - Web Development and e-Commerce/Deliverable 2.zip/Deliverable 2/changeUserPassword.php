<?php
echo "<link rel='stylesheet' href='style.css'>";
echo "<div class='form-accountDetails'>";
$success = false;
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userType = $_POST["userType"];
    $connectionActive = false;
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $userID = $_POST["userID"];
        $password = $_POST["password"];
        $newPassword = $_POST["newPassword"];
        $conPassword = $_POST["conPassword"];
        $errors = [];

        if (empty($password)) {
            $errors[] = "Password is required";
        }
        if (empty($newPassword)) {
            $errors[] = "Password is required";
        }
        else if (strlen($newPassword) < 8){
            $errors[] = "New password must be at least 8 characters or more in length";
        }

        if (empty($conPassword)) {
            $errors[] = "Password is required";
        }
        else if ($conPassword !== $newPassword){
            $errors[] = "New password and confirmation password don't match";
        }

        $userDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM $userType WHERE ". $userType ."ID = ?", [$userID]));
        if (!password_verify($password, $userDetails["password"])){
            $errors[] = "Password is incorrect";
        }

        if (empty($errors)) {
            mysqli_execute_query($connection, "Update $userType SET password = ? WHERE ". $userType ."ID = ?", [password_hash($newPassword, PASSWORD_DEFAULT), $userID]);
            $_SESSION["message"] = "Password changed successfully";
            mysqli_commit($connection);
            $success = true;
        }
        else {
            echo "<h1>Account login error</h1>";
            echo "<h3>Password couldn't be changed due to the following error(s):</h3>";
            echo "<div class='form-errorBoard error'>";
            foreach ($errors as $error) {
                echo "<h4>*$error</h4>";
            }
            echo "</div>";

            if ($userType != "admin"){
                echo "<a href='mainWebsite/accountCenter(PassAndSec).php' class='form-returnLink'>Return to Account Center</a>";
            }
            else{
                echo "<a href='adminWebsite/adminDatabase.php' class='form-returnLink'>Return to admin database</a>";
            }
        }
    }
    catch(Exception $error){
        echo "<h1>Account login error</h1>";
        echo "<h3>Password couldn't be changed due to the following error(s):</h3>";
        echo "<div class='form-errorBoard error'>";
            echo "<h4>*Error: ". $error->getMessage() ."</h4>";
        echo "</div>";

        if ($userType != "admin"){
            echo "<a href='mainWebsite/accountCenter(PassAndSec).php' class='form-returnLink'>Return to Account Center</a>";
        }
        else{
            echo "<a href='adminWebsite/adminDatabase.php' class='form-returnLink'>Return to admin database</a>";
        }

        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $_SESSION["message"] = "Error: POST error occured";
}
echo "</div>";

if ($success == true){
    if ($userType != "admin"){
        header('Location:mainWebsite/accountCenter(PassAndSec).php');
    }
    else{
        header('Location:adminWebsite/adminDatabase.php');
    }
}
?>