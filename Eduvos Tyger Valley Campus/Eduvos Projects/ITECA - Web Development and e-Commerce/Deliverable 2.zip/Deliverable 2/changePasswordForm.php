<?php
$success = false;
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userID = $_POST["formBtn"];
    $userType = $_POST["userType"];
    echo "<html lang='en'>";

    echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
        echo "<title>Change password</title>";
        echo "<link rel='stylesheet' href='style.css'>";
    echo "</head>";

    if ($userType != 'admin'){
        echo "<header>";
            echo "<h1><a href='index.php'>Marketplace</a></h1>";
            echo "<div class='form-mainHeading'>";
                echo "<div class='form-account'>";
                    echo "<a href='index.php'>Return to the store front</a>";
                echo "</div>";
            echo "</div>";
        echo "</header>";
    }

    echo "<body>";
        echo "<div class='form-accountDetails'>";
            echo "<h1>Update password</h1>";
            echo "<form action='changeUserPassword.php' method='POST' onsubmit='return validatePasswords()'>";
                echo "<input type='hidden' value='$userID' id='userID' name='userID'>";
                echo "<input type='hidden' value='$userType' id='userType' name='userType'>";

                echo "<div class='form-changePassDetails'>";
                    echo "<div class='form-inputDetails'>";
                        echo "<label for='password'>Password: </label><br>";
                        echo "<div class='form-error'>";
                            echo "<input type='password' name='password' id='password'>";
                            echo "<small class='error' id='passwordError'></small>";
                        echo "</div>";
                    echo "</div>";
                echo "</div>";

                echo "<div class='form-changePassDetails'>";
                    echo "<div class='form-inputDetails'>";
                        echo "<label for='newPassword'>New password: </label><br>";
                        echo "<div class='form-error'>";
                            echo "<input type='password' name='newPassword' id='newPassword'>";
                            echo "<small class='error' id='newPasswordError'></small>";
                        echo "</div>";
                    echo "</div>";
                echo "</div>";

              echo "<div class='form-changePassDetails'>";
                  echo "<div class='form-inputDetails'>";
                      echo "<label for='conPassword'>Confirm new password: </label><br>";
                      echo "<div class='form-error'>";
                          echo "<input type='password' name='conPassword' id='conPassword'>";
                          echo "<small class='error' id='conPasswordError'></small>";
                      echo "</div>";
                  echo "</div>";
              echo "</div>";

              echo "<button type='submit' class='form-btnSpace'>Change password</button>";
          echo "</form>";
          echo "<script src='script.js'></script>";
      echo "</div>";
  echo "</body>";
  echo "</html>";
}
echo "</div>";
?>