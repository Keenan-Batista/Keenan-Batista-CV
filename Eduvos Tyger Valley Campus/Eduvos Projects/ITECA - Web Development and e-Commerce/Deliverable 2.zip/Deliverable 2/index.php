<?php
session_start();
$accountLink = "mainWebsite/accountRegistration.html";
$sqlStatement = "SELECT * FROM listing";

if (isset($_SESSION["userID"]) && !empty($_SESSION["userID"])){
    $accountLink = "mainWebsite/accountCenter(ProfileDetails).php";
}

echo "<html lang='en'>";
echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>Marketplace</title>";
    echo "<link rel='stylesheet' href='style.css'>";
echo "</head>";

if (isset($_SESSION["searchStatement"]) && !empty($_SESSION["searchStatement"])){
    $sqlStatement = $_SESSION["searchStatement"];
    unset($_SESSION["searchStatement"]);
}

if (isset($_SESSION["message"]) && !empty($_SESSION["message"])){
    echo "<div id='message' name='message' class='msg'>";
        echo "<p>". $_SESSION["message"] ."</p>";
        echo "<button onclick='closeMessage()'>X</button>";
    echo "</div>";
    unset($_SESSION["message"]);
    echo "<script src='script.js'></script>";
}

echo "<header>";
    echo "<h1><a href='index.php'>Marketplace</a></h1>";
    echo "<nav>";
        echo "<div class='form-mainHeading'>";
            if (isset($_SESSION["userType"])) {
                if ($_SESSION["userType"] == "vendor") {
                    echo "<div class='form-account'>";
                        echo "<a href='mainWebsite/createListing.html'>Create listing</a>";
                    echo "</div>";
                }
            }
            echo "<div class='form-account'>";
                echo "<a href=' $accountLink '>My Account</a>";
            echo "</div>";

            if (isset($_SESSION["userID"])){
                echo "<a href='mainWebsite/cart.php'><button>Cart</button></a>";
            }
            else{
                echo "<a href='mainWebsite/cart.php'><button disabled>Cart</button></a>";
            }
            
        echo "</div>";
    echo "</nav>";
echo "</header>";

echo "<body>";
    echo "<form action='searchDatabase.php' method='POST'>";
        echo "<div class='form-searchBar'>";
            echo "<div class='form-searchBarItem'>";
                echo "<input type='hidden' id='isAdmin' name='isAdmin' value='false'>";
                echo "<select id='infoPriority' name='infoPriority'>";
                    echo "<option value='title'>Search by Title</option>";
                    echo "<option value='price'>Search by Price</option>";
                    echo "<option value='category'>Search by Category</option>";
                echo "</select>";

                echo "<select id='orderItem' name='orderItem'>";
                    echo "<option value='title'>Sort by Title</option>";
                    echo "<option value='price'>Sort by Price</option>";
                    echo "<option value='category'>Sort by Category</option>";
                echo "</select>";

                echo "<select id='adPriority' name='adPriority'>";
                    echo "<option value='ASC'>Order in Ascending</option>";
                    echo "<option value='DESC'>Order in Descending</option>";
                    echo "<option value='None'>None</option>";
                echo "</select>";
            echo "</div>";

            echo "<div class='form-inputAndBtn'>";
                echo "<input type='search' id='searchBar' name='searchBar'>";
                echo "<button type='submit' name='tableBtn' id='tableBtn' value='listing'>&rarr;</button>";
            echo "</div>";
        echo "</div>";
    echo "</form>";

    echo "<div class='form-productsGridContainer'>";
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $connection = null;
        
        try{
            $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
            if ($listingRecords = mysqli_execute_query($connection, $sqlStatement)){
                if(mysqli_num_rows($listingRecords) > 0){
                    while($recordDetails = mysqli_fetch_array($listingRecords)){
                        $vendorDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM vendor WHERE vendorID = ?", [$recordDetails["vendorID"]]));
                        echo "<div class='form-productsGridItem'>";
                            echo "<div class='form-productsGridItemImage'>";
                                echo "<form action='mainWebsite/productPage.php' method='POST'>";
                                    echo "<button type='submit' id='formBtn' name='formBtn' value='". $recordDetails["listingID"] ."'><img src='". $recordDetails["image"] ."' alt='Product.png'></button>";
                                echo "</form>";
                            echo "</div>";

                            echo "<div class='form-productsGridVendor'>";
                                echo "<h2>". $vendorDetails["username"] ."</h2>";
                            echo "</div>";

                            echo "<h3>". $recordDetails["title"] ."</h3>";
                            echo "<h4 class='form-cost'>R ". $recordDetails["price"] ."</h4>";
                            echo "<h4>". $recordDetails["category"] ."</h4>";

                            echo "<form action='mainWebsite/addToCart.php' method='POST'>";
                                if (isset($_SESSION["userID"])){
                                    $deliveryDetails = mysqli_fetch_array(mysqli_execute_query($connection, "SELECT * FROM delivery WHERE userType = ? AND userID = ? AND vendorID = ?", [$_SESSION["userType"], $_SESSION["userID"], $recordDetails["vendorID"]]));
                                    if ($recordDetails["vendorID"] == $_SESSION["userID"] && $_SESSION["userType"] == 'vendor'){
                                        echo "<button name='productBtn' id='productBtn' value='-2'>Your listing</button>";
                                    }
                                    else{
                                        if (!isset($deliveryDetails["deliveryID"])){
                                            echo "<input type='hidden' name='vendorID' id='vendorID' value='". $recordDetails["vendorID"] ."'>";
                                            echo "<button type='submit' name='productBtn' id='productBtn' value='". $recordDetails["listingID"] ."'>Add to cart</button>";
                                        }
                                        else{
                                            if ($cartItems = mysqli_execute_query($connection, "SELECT * FROM cartItem WHERE deliveryID = ? AND listingID = ?", [$deliveryDetails["deliveryID"], $recordDetails["listingID"]])){
                                                if(mysqli_num_rows($cartItems) <= 0){
                                                    echo "<input type='hidden' name='vendorID' id='vendorID' value='". $recordDetails["vendorID"] ."'>";
                                                    echo "<button type='submit' name='productBtn' id='productBtn' value='". $recordDetails["listingID"] ."'>Add to cart</button>";
                                                }
                                                else{
                                                    echo "<button type='submit' name='productBtn' id='productBtn' value='-1'>In cart</button>";
                                                }
                                            }
                                        }
                                    }
                                }
                                else{
                                    echo "<button disabled>Add to cart</button>";
                                }
                            echo "</form>";
                        echo "</div>";
                    }
                }
            }
        }
        catch(Exception $error){
            echo "<h2>". $error->getMessage() ."</h2>";
        }

        if ($connection != null){
            $connection->close();
        }
    echo "</div>";
echo "</body>";
echo "</html>";
?>

