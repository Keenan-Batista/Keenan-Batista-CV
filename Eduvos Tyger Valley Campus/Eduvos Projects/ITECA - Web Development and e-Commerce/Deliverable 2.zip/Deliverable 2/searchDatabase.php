<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $infoPriority = $_POST["infoPriority"];
    $adPriority = $_POST["adPriority"];
    $orderItem = $_POST["orderItem"];
    $searchBar = strtolower($_POST["searchBar"]);
    $databaseTbl = $_POST["tableBtn"];
    $isAdmin = $_POST["isAdmin"];

    if (trim($searchBar) == ""){
        if ($adPriority == "None"){
            $sqlStatement = "SELECT * FROM ". $databaseTbl ."";
        }
        else{
            if ($databaseTbl == 'listing' && $orderItem == 'username'){
                $sqlStatement = "SELECT * FROM listing INNER JOIN vendor ON vendor.vendorID = listing.vendorID ORDER BY vendor.username $adPriority";
            }
            else{
                $sqlStatement = "SELECT * FROM ". $databaseTbl ." ORDER BY $orderItem $adPriority";
            }
        }
    }
    else{
        if ($adPriority == "None"){
            if ($databaseTbl == 'listing' && $infoPriority == 'username'){
                $sqlStatement = "SELECT * FROM ". $databaseTbl ." WHERE vendorID = (SELECT vendorID FROM vendor WHERE username LIKE '%$searchBar%')";
            }
            else{
                $sqlStatement = "SELECT * FROM ". $databaseTbl ." WHERE $infoPriority LIKE '%$searchBar%'";
            }
        }
        else{
            if ($databaseTbl == 'listing' && $orderItem == 'username'){
                if ($databaseTbl == 'listing' && $infoPriority == 'username'){
                    $sqlStatement = "SELECT * FROM listing INNER JOIN vendor ON vendor.vendorID = listing.vendorID WHERE vendor.username LIKE '%$searchBar%' ORDER BY vendor.username $adPriority";
                }
                else{
                    $sqlStatement = "SELECT * FROM listing INNER JOIN vendor ON vendor.vendorID = listing.vendorID WHERE $infoPriority LIKE '%$searchBar%' ORDER BY vendor.username $adPriority";
                }
            }
            else{
                if ($databaseTbl == 'listing' && $infoPriority == 'username'){
                    $sqlStatement = "SELECT * FROM ". $databaseTbl ." WHERE vendorID = (SELECT vendorID FROM vendor WHERE username LIKE '%$searchBar%')";
                }
                else{
                    $sqlStatement = "SELECT * FROM ". $databaseTbl ." WHERE $infoPriority LIKE '%$searchBar%' ORDER BY $orderItem $adPriority";
                }
            }
        }
    }

    $_SESSION["searchStatement"] = $sqlStatement;

    if ($isAdmin == "true"){
        header("Location:adminWebsite/". $databaseTbl ."Database.php");
    }
    else{
        header("Location:index.php");
    }
}
?>