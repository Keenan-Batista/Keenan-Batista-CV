<?php
session_start();
$sqlStatement = "SELECT * FROM buyer";

echo "<html lang='en'>";
echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>Users</title>";
    echo "<link rel='stylesheet' href='../style.css'>";
echo "</head>";

if (isset($_SESSION["searchStatement"]) && !empty($_SESSION["searchStatement"])){
    $sqlStatement = $_SESSION["searchStatement"];
    unset($_SESSION["searchStatement"]);
}

if (isset($_SESSION["message"]) && !empty($_SESSION["message"])){
    echo "<div id='message' name='message' class='msg'>";
        echo "<p>". $_SESSION["message"] ."</p>";
        echo "<button onclick='closeMessage()'>X</button>";
    echo "</div>";
    unset($_SESSION["message"]);
    echo "<script src='../script.js'></script>";
}

echo "<body>";
    echo "<div class='form-accountCenter'>";
        echo "<div class='form-accountCenterOptions'>";
            echo "<h1 >Admin center</h1>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='adminDatabase.php'>Admin database</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem form-accCenterOptionPicked'>";
                echo "<a href='buyerDatabase.php'>Buyer database</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='vendorDatabase.php'>Vendor database</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='listingDatabase.php'>Listing database</a>";
            echo "</div>";
        echo "</div>";

        echo "<div class='form-settingOptions'>";
            echo "<div class='form-settingOptionsSideItems'>";
                echo "<h2>Welcome ". $_SESSION["username"] ."</h2>";
                echo "<div class='form-inputDetails'>";
                    echo "<form action='../accountLogOut.php' method='POST'>";
                        echo "<button>Log out</button>";
                    echo "</form>";
                echo "</div>";
            echo "</div>";
            echo "<a class='form_buttonLink' href='userCreation.html'><button>Create a new user account</button></a>";

            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            $connection = null;

            try{
                $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
                echo "<div class='form-centeredBar'>";
                    echo "<form action='../searchDatabase.php' method='POST'>";
                        echo "<div class='form-searchBar'>";
                            echo "<div class='form-searchBarItem'>";
                                echo "<input type='hidden' id='isAdmin' name='isAdmin' value='true'>";
                                echo "<select id='infoPriority' name='infoPriority'>";
                                    echo "<option value='buyerID'>Search by Buyer ID</option>";
                                    echo "<option value='username'>Search by Username</option>";
                                    echo "<option value='email'>Search by Email</option>";
                                    echo "<option value='address'>Search by Address</option>";
                                    echo "<option value='buyerRating'>Search by Buyer Rating</option>";
                                echo "</select>";

                                echo "<select id='orderItem' name='orderItem'>";
                                    echo "<option value='buyerID'>Order by Buyer ID</option>";
                                    echo "<option value='username'>Order by Username</option>";
                                    echo "<option value='email'>Order by Email</option>";
                                    echo "<option value='address'>Order by Address</option>";
                                    echo "<option value='buyerRating'>Order by Buyer Rating</option>";
                                echo "</select>";

                                echo "<select id='adPriority' name='adPriority'>";
                                    echo "<option value='ASC'>Order in Ascending</option>";
                                    echo "<option value='DESC'>Order in Descending</option>";
                                    echo "<option value='None'>None</option>";
                                echo "</select>";
                            echo "</div>";

                            echo "<div class='form-inputAndBtn'>";
                                echo "<input type='search' id='searchBar' name='searchBar'>";
                                echo "<button type='submit' name='tableBtn' id='tableBtn' value='listing'>&rarr;</button>";
                            echo "</div>";
                        echo "</div>";
                    echo "</form>";
                echo "</div>";
                
                echo "<div class='form-databaseBlock form-description'>";
                    if ($buyers = mysqli_execute_query($connection, $sqlStatement)){
                        if (mysqli_num_rows($buyers) > 0){
                            echo "<table>";
                                echo "<tr class='form-tableHead'>";
                                    echo "<th>Buyer ID</th>";
                                    echo "<th>Username</th>";
                                    echo "<th>First name</th>";
                                    echo "<th>Last name</th>";
                                    echo "<th>Phone number</th>";
                                    echo "<th>Email</th>";
                                    echo "<th>Address</th>";
                                    echo "<th>Buyer rating</th>";
                                    echo "<th></th>";
                                    echo "<th></th>";
                                echo "</tr>";

                                
                                while($buyerDetails = mysqli_fetch_array($buyers)){
                                    echo "<tr>";
                                        echo "<td>". $buyerDetails["buyerID"] ."</td>";
                                        echo "<td>". $buyerDetails["username"] ."</td>";
                                        echo "<td>". $buyerDetails["firstName"] ."</td>";
                                        echo "<td>". $buyerDetails["lastName"] ."</td>";
                                        echo "<td>". $buyerDetails["phoneNum"] ."</td>";
                                        echo "<td>". $buyerDetails["email"] ."</td>";
                                        echo "<td>". $buyerDetails["address"] ."</td>";
                                        echo "<td>". $buyerDetails["buyerRating"] ."</td>";

                                        echo "<form action='changeUserType.php' method='POST'>";
                                            echo "<input type='hidden' value='buyer' name='userType' id='userType'>";
                                            echo "<td><button type='submit' value='". $buyerDetails["buyerID"] ."' name='formBtn' id='formBtn'>Transition to vendor</button></td>";
                                        echo "</form>";
                                        echo "<form action='../deleteRecord.php' method='POST'>";
                                            echo "<input type='hidden' value='buyer' name='recordType' id='recordType'>";
                                            echo "<td><button type='submit' value='". $buyerDetails["buyerID"] ."' name='formBtn' id='formBtn' class='form-redBtn'>Delete</button></td>";
                                        echo "</form>";
                                    echo "</tr>";
                                }
                            echo "</table>";
                        }
                    }
                echo "</div>";
            }
            catch(Exception $error){
                echo "<h2>An error occured</h2>";
            }
        echo "</div>";
        
        if ($connection != null){
            $connection->close();
        }
    echo "</div>";
echo "</body>";
echo "</html>";
?>