<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
    
    if ($connection->connect_error) {
        die("Connection has failed:" . $connection->connect_error);
    }
    else {
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);

        try{
            $userType = $_POST["userType"];
            $userID = $_POST["formBtn"];
            $otherUserType = null;

            if ($userType == "buyer"){
                $otherUserType = "vendor";
            }
            else{
                $otherUserType = "buyer";
            }

            $userDetails = mysqli_fetch_array(mysqli_query($connection, "SELECT * FROM $userType WHERE ". $userType ."ID = '$userID'"));
            if ($otherUserType == "buyer"){
                mysqli_query($connection, "INSERT INTO buyer (firstName, lastName, username, phoneNum, email, address, password, buyerRating, eWalletAmount, notify) VALUES ('". $userDetails["firstName"] ."', '". $userDetails["lastName"] ."', '". $userDetails["username"] ."', '". $userDetails["phoneNum"] ."', '". $userDetails["email"] ."', '". $userDetails["address"] ."', '". $userDetails["password"] ."', '". $userDetails["buyerRating"] ."', '". $userDetails["eWalletAmount"] ."', '". $userDetails["notify"] ."')");
            }
            else{
                mysqli_query($connection, "INSERT INTO vendor (firstName, lastName, username, phoneNum, email, address, password, buyerRating, eWalletAmount, vendorRating, notify) VALUES ('". $userDetails["firstName"] ."', '". $userDetails["lastName"] ."', '". $userDetails["username"] ."', '". $userDetails["phoneNum"] ."', '". $userDetails["email"] ."', '". $userDetails["address"] ."', '". $userDetails["password"] ."', '". $userDetails["buyerRating"] ."', '". $userDetails["eWalletAmount"] ."', 0, '". $userDetails["notify"] ."')");
            }

            $newUserDetails = mysqli_fetch_array(mysqli_query($connection, "SELECT * FROM $otherUserType WHERE username = '". $userDetails["username"] ."'"));
            mysqli_query($connection, "Delete FROM $userType WHERE ". $userType ."ID = '$userID'");

            $image = null;
            if ($userType == 'vendor'){
                $deliveries = mysqli_fetch_array(mysqli_query($connection, "SELECT * FROM delivery WHERE vendorID = '". $userDetails["vendorID"] ."'"));
                mysqli_query($connection, "DELETE FROM delivery WHERE deliveryID = '". $deliveries["deliveryID"] ."'");
                mysqli_query($connection, "DELETE FROM deliveryMessage WHERE deliveryID = '". $deliveries["deliveryID"] ."'");

                if ($listingDetails = mysqli_query($connection, "SELECT * FROM listing WHERE vendorID = '". $userDetails["vendorID"] ."'")){
                    if(mysqli_num_rows($listingDetails) > 0){
                        while($recordDetails = mysqli_fetch_array($listingDetails)){
                            mysqli_query($connection, "Delete FROM listing WHERE listingID = '". $recordDetails["listingID"] ."'");
                            
                            $cartItems = mysqli_query($connection, "SELECT * FROM cartItem WHERE listingID = '". $recordDetails["listingID"] ."'");
                            if (mysqli_num_rows($cartItems) > 0){
                                while ($cartItem = mysqli_fetch_array($cartItems)){
                                    mysqli_query($connection, "Delete FROM cartItem WHERE cartItemID = '". $cartItem["cartItemID"] ."'");
                                }
                            }
                            $image = substr($recordDetails["image"], 3);
                        }
                    }
                } 
            }
            else{
                mysqli_query($connection, "Update delivery SET userID = '". $newUserDetails["vendorID"] ."' WHERE userID = '". $userDetails["buyerID"] ."' AND userType = 'buyer'");
                mysqli_query($connection, "Update delivery SET userType = 'vendor' WHERE userID = '". $newUserDetails["vendorID"] ."' AND userType = 'buyer'");
                mysqli_query($connection, "Update userRatingHistory SET userID = '". $newUserDetails["vendorID"] ."' WHERE userID = '". $userDetails["buyerID"] ."'");
                mysqli_query($connection, "Update userRatingHistory SET userType = 'vendor' WHERE userID = '". $newUserDetails["vendorID"] ."'");
            }

            $_SESSION["message"] = "Account transitioned successfully";
            mysqli_commit($connection);
            if ($image != null){
                unlink($image);
            }
        }
        catch(Exception $error){
            $_SESSION["message"] = "Error: ". $error->getMessage();
            mysqli_rollback($connection);
        }   
    }
    if ($connection != null){
        $connection->close();
    }
}
else{
    $_SESSION["message"] = "Error: POST error occured";
}

header('Location:'. $userType .'Database.php');
?>