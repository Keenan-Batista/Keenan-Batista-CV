<?php
echo "<link rel='stylesheet' href='../style.css'>";
echo "<div class='form-accountDetails'>";
$success = false;
$connectionActive = false;
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try {
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $userType = $_POST["userType"];
        $firstName = $_POST["fName"];
        $lastName = $_POST["lName"];
        $username = $_POST["username"];
        $phoneNum = $_POST["phoneNum"];
        $email = $_POST["email"];
        $address = $_POST["address"];
        $password = $_POST["password"];
        $conPassword = $_POST["conPassword"];
        $notify = isset($_POST["notify"]);

        $errors = [];

        if (empty($firstName)) {
            $errors[] = "First name is required";
        }
        if (empty($lastName)) {
            $errors[] = "Last name is required";
        }
        if (empty($username)) {
            $errors[] = "Username is required";
        }
        else{
            $sqlUsernameB = mysqli_execute_query($connection, "SELECT username FROM buyer WHERE username = ?", [$username]);
            if (mysqli_num_rows($sqlUsernameB) > 0){
                $errors[] = "Username already exists";
            }
            else{
                $sqlUsernameV = mysqli_execute_query($connection, "SELECT username FROM vendor WHERE username = ?", [$username]);
                if (mysqli_num_rows($sqlUsernameV) > 0){
                    $errors[] = "Username already exists";
                }
                else{
                    $sqlUsernameA = mysqli_execute_query($connection, "SELECT username FROM admin WHERE username = ?", [$username]);
                    if (mysqli_num_rows($sqlUsernameA) > 0){
                        $errors[] = "Username already exists";
                    }
                }
            }
        }

        if (empty($phoneNum)) {
            $errors[] = "Phone number is required";
        }

        if (empty($email)) {
            $errors[] = "Email is required";
        } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email";
        }

        if (empty($address)) {
            $errors[] = "Address is required";
        }

        if (empty($password)) {
            $errors[] = "Password is required";
        } else if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 or more characters in length";
        }

        if (empty($conPassword)) {
            $errors[] = "Password must be repeated for confirmation";
        } else if ($password != $conPassword) {
            $errors[] = "Password and confirmation password don't match";
        }

        if (empty($errors)) {
            $notifyChecked = 0;
            if (!empty($notify)){
                $notifyChecked = 1;
            }

            mysqli_execute_query($connection, "INSERT INTO $userType (firstName, lastName, username, phoneNum, email, address, password, buyerRating, eWalletAmount, notify) VALUES (?, ?, ?, ?, ?, ?, ?, '0', '0', ?)", [$firstName, $lastName, $username, $phoneNum, $email, $address, password_hash($password, PASSWORD_DEFAULT), $notifyChecked]);;
            mysqli_commit($connection);
            $success = true;
            $_SESSION["message"] = "User created successfully";
        } else {
            echo "<h1>User creation error</h1>";
            echo "<h3>User couldn't be created due to the following error(s):</h3>";
            echo "<div class='form-errorBoard error'>";
                foreach ($errors as $error) {
                    echo "<h4>$error</h4>";
                }
            echo "</div>";
            echo "<a href='userCreation.html' class='form-returnLink'>Return to creation page</a>";
        }
    }
    catch(Exception $error){
        echo "<h1>User creation error</h1>";
        echo "<h3>User couldn't be created due to the following error(s):</h3>";
        echo "<div class='form-errorBoard error'>";
            echo "<h4>Error: ". $error->getMessage() ."</h4>";
        echo "</div>";
        echo "<a href='userCreation.html' class='form-returnLink'>Return to creation page</a>";

        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }

    if ($connection != null){
        $connection->close();
    }
} else {
    $success = true;
    $_SESSION["message"] = "Error: POST error occured";
}
echo "</div>";

if ($success == true){
    if ($userType == "buyer"){
        header('Location:buyerDatabase.php');
    }
    else{
        header('Location:vendorDatabase.php');
    }
}
?>