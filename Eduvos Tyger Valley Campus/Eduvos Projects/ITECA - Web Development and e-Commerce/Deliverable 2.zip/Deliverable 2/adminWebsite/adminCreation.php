<?php
echo "<link rel='stylesheet' href='../style.css'>";
echo "<div class='form-accountDetails'>";
$success = false;
$connectionActive = false;
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $connection = null;

    try{
        $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
        mysqli_autocommit($connection, false);
        mysqli_begin_transaction($connection);
        $connectionActive = true;

        $username = $_POST["username"];
        $password = $_POST["password"];
        $conPassword = $_POST["conPassword"];
        $errors = [];

        if (empty($username)) {
            $errors[] = "Username is required";
        }
        else{
            $sqlUsername = mysqli_execute_query($connection, "SELECT * FROM admin WHERE username = '$username'");
            if (mysqli_num_rows($sqlUsername) > 0){
                $errors[] = "Username already exists";
            }
        }

        if (empty($password)) {
            $errors[] = "Password is required";
        } else if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 or more characters in length";
        }

        if (empty($conPassword)) {
            $errors[] = "Password must be repeated for confirmation";
        } else if ($password != $conPassword) {
            $errors[] = "Password and confirmation password don't match";
        }

        if (empty($errors)) {
            mysqli_execute_query($connection, "INSERT INTO admin (username, password) VALUES (?, ?)", [$username, password_hash($password, PASSWORD_DEFAULT)]);
            $success = true;
            $_SESSION["message"] = "Account registered successfully";  
            mysqli_commit($connection);     
        } else {
            echo "<h1>Admin creation error</h1>";
                echo "<h3>Account couldn't be registered due to the following errors:</h3>";
            echo "<div class='form-errorBoard error'>";
                foreach ($errors as $error) {
                    echo "<h4>$error</h4>";
                }
            echo "</div>";
            echo "<a href='adminCreation.html' class='form-returnLink'>Return to account creation page</a>";
        }
    }
    catch(Exception $error){
        echo "<h1>Admin creation error</h1>";
        echo "<h3>Account couldn't be registered due to the following errors:</h3>";
        echo "<div class='form-errorBoard error'>";
            echo "<h4>*Error: ". $error->getMessage() ."</h4>";
        echo "</div>";
        echo "<a href='adminCreation.html' class='form-returnLink'>Return to account creation page</a>";

        if ($connectionActive == true){
            mysqli_rollback($connection);
        }
    }
    if ($connection != null){
        $connection->close();
    }

} else {
    $_SESSION["message"] = "Error: POST error occured";
}
echo "</div>";

if ($success == true){
    header('Location:adminDatabase.php');
}
?>