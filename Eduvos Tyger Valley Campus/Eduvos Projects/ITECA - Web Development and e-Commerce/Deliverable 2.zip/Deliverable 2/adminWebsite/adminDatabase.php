<?php
session_start();
$sqlStatement = "SELECT * FROM admin";

echo "<html lang='en'>";
echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<title>Users</title>";
    echo "<link rel='stylesheet' href='../style.css'>";
echo "</head>";

if (isset($_SESSION["searchStatement"]) && !empty($_SESSION["searchStatement"])){
    $sqlStatement = $_SESSION["searchStatement"];
    unset($_SESSION["searchStatement"]);
}

if (isset($_SESSION["message"]) && !empty($_SESSION["message"])){
    echo "<div id='message' name='message' class='msg'>";
        echo "<p>". $_SESSION["message"] ."</p>";
        echo "<button onclick='closeMessage()'>X</button>";
    echo "</div>";
    unset($_SESSION["message"]);
    echo "<script src='../script.js'></script>";
}

echo "<body>";
    echo "<div class='form-accountCenter'>";
        echo "<div class='form-accountCenterOptions'>";
            echo "<h1 >Admin center</h1>";
            echo "<div class='form-accountCenterOptionsItem form-accCenterOptionPicked'>";
                echo "<a href='adminDatabase.php'>Admin database</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='buyerDatabase.php'>Buyer database</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='vendorDatabase.php'>Vendor database</a>";
            echo "</div>";
            echo "<div class='form-accountCenterOptionsItem'>";
                echo "<a href='listingDatabase.php'>Listing database</a>";
            echo "</div>";
        echo "</div>";

        echo "<div class='form-settingOptions'>";
            echo "<div class='form-settingOptionsSideItems'>";
                echo "<h2>Welcome ". $_SESSION["username"] ."</h2>";
                echo "<div class='form-inputDetails'>";
                    echo "<form action='../accountLogOut.php' method='POST'>";
                        echo "<button>Log out</button>";
                    echo "</form>";
                echo "</div>";
            echo "</div>";

            if ($_SESSION["userID"] == 1){
                echo "<a class='form_buttonLink' href='adminCreation.html'><button>Create a new admin account</button></a>";
            }
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            $connection = null;

            try{
                $connection = new mysqli("sql110.infinityfree.com", "if0_42189270", "0hPbQOshRVNsm9b", "if0_42189270_c2cmarketplacedb");
                echo "<div class='form-centeredBar'>";
                    echo "<form action='../searchDatabase.php' method='POST'>";
                        echo "<div class='form-searchBar'>";
                            echo "<div class='form-searchBarItem'>";
                                echo "<input type='hidden' id='isAdmin' name='isAdmin' value='true'>";
                                echo "<select id='infoPriority' name='infoPriority'>";
                                    echo "<option value='adminID'>Search by Admin ID</option>";
                                    echo "<option value='username'>Search by Username</option>";
                                echo "</select>";

                                echo "<select id='orderItem' name='orderItem'>";
                                    echo "<option value='adminID'>Order by Admin ID</option>";
                                    echo "<option value='username'>Order by Username</option>";
                                echo "</select>";
                                
                                echo "<select id='adPriority' name='adPriority'>";
                                    echo "<option value='ASC'>Order in Ascending</option>";
                                    echo "<option value='DESC'>Order in Descending</option>";
                                    echo "<option value='None'>None</option>";
                                echo "</select>";
                            echo "</div>";

                            echo "<div class='form-inputAndBtn'>";
                                echo "<input type='search' id='searchBar' name='searchBar'>";
                                echo "<button type='submit' name='tableBtn' id='tableBtn' value='listing'>&rarr;</button>";
                            echo "</div>";
                        echo "</div>";
                    echo "</form>";
                echo "</div>";

                echo "<div class='form-databaseBlock form-description'>";
                    if ($admins = mysqli_execute_query($connection, $sqlStatement)){
                        if (mysqli_num_rows($admins) > 0){
                            echo "<table>";
                                echo "<tr class='form-tableHead'>";
                                    echo "<th>Admin ID</th>";
                                    echo "<th>Username</th>";
                                    if ($_SESSION["userID"] == 1){
                                        echo "<th></th>";
                                        echo "<th></th>";
                                    }
                                echo "</tr>";
                                
                                while($adminDetails = mysqli_fetch_array($admins)){
                                    echo "<tr>";
                                        echo "<td>". $adminDetails["adminID"] ."</td>";
                                        echo "<td>". $adminDetails["username"] ."</td>";

                                        if ($_SESSION["userID"] == 1){
                                            echo "<form action='../changePasswordForm.php' method='POST'>";
                                                echo "<input type='hidden' value='admin' name='userType' id='userType'>";
                                                echo "<td><button type='submit' value='". $adminDetails["adminID"] ."' name='formBtn' id='formBtn'>Update password</button></td>";
                                            echo "</form>";

                                            if ($adminDetails["adminID"] != 1){
                                                echo "<form action='../deleteRecord.php' method='POST'>";
                                                    echo "<input type='hidden' value='admin' name='recordType' id='recordType'>";
                                                    echo "<td><button type='submit' value='". $adminDetails["adminID"] ."' name='formBtn' id='formBtn' class='form-redBtn'>Delete</button></td>";
                                                echo "</form>";
                                            }
                                        }
                                    echo "</tr>";
                                }
                            echo "</table>";
                        }
                    }
                echo "</div>";
            }
            catch(Exception $error){
                echo "<h2>An error occured</h2>";
            }

            if ($connection != null){
                $connection->close();
            }
        echo "</div>";
    echo "</div>";
echo "</body>";
echo "</html>";
?>