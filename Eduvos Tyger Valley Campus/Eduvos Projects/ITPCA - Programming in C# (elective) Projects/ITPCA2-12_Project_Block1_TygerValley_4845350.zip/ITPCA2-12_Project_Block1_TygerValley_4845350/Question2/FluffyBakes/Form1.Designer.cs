﻿namespace FluffyBakes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private Button addBtn;
        private TextBox addProductNameText;
        private TextBox addProductCategoryText;
        private TextBox addProductPriceText;
        private TextBox addProductQuantityText;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Button searchBtn;
        private Label label12;
        private TextBox searchProductText;
        private Label sNamelbl;
        private Label sCategorylbl;
        private Label sPricelbl;
        private Label sQuantitylbl;
        private Label productFoundlbl;
        private Label label1;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox updateProductQuantityText;
        private TextBox updateProductPriceText;
        private TextBox updateProductCategoryText;
        private Button updateProductBtn;
        private Label addProductlbl;
        private Label updateProductlbl;
        private TextBox updateProductIDText;
        private Label label16;
        private Button updateBtn;
        private Button deleteProductBtn;
        private TextBox deleteProductIDText;
        private Label label17;
        private Label deleteProductlbl;
        private Label label19;
        private Label bakeryNamelbl;
    }
}
