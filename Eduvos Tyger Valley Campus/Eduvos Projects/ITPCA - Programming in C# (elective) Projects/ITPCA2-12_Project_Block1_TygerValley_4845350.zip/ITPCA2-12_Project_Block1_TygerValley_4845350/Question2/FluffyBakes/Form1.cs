using System.Data.SqlClient;

namespace FluffyBakes
{
    public partial class Form1 : Form
    {
        public static class global
        {
            public static string connectionString = "Data Source=LAPTOP-I4QHKHD9\\SQLEXPRESS02;Initial Catalog=FluffyBakes_DB;Integrated Security=True;Connect Timeout=30;Encrypt=False";
            public static SqlConnection con = new SqlConnection(connectionString);
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            string productName = "", productCategory = "", productID = "", tempProductNum = "";
            int productQuantity = 0, highestProductIDNum = 0;
            double productPrice = 0.0;
            bool validInput = true;

            global.con.Open();
            string query = "SELECT productID FROM Products";
            SqlCommand cmd = new SqlCommand(query, global.con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                productID = reader.GetString(0);
                tempProductNum = "";
                for (int i = 1; i < productID.Length; i++)
                {
                    tempProductNum += productID[i];
                }

                if (highestProductIDNum < Convert.ToInt32(tempProductNum))
                {
                    highestProductIDNum = Convert.ToInt32(tempProductNum);
                }
            }

            productID = "p" + Convert.ToString((Convert.ToInt32(highestProductIDNum) + 1));
            reader.Close();

            if (!string.IsNullOrEmpty(addProductNameText.Text))
            {
                try
                {
                    productName = addProductNameText.Text;
                }
                catch (Exception EX)
                {
                    addProductlbl.Text = $"Product's name error: {EX.Message}";
                    validInput = false;
                }
            }
            else
            {
                addProductlbl.Text = "Product's name error: It was left blank!";
                validInput = false;
            }

            if (validInput == true)
            {
                if (!string.IsNullOrEmpty(addProductCategoryText.Text))
                {
                    try
                    {
                        productCategory = addProductCategoryText.Text;
                    }
                    catch (Exception EX)
                    {
                        addProductlbl.Text = $"Product's category error: {EX.Message}";
                        validInput = false;
                    }
                }
                else
                {
                    addProductlbl.Text = "Product's category error: It was left blank!";
                    validInput = false;
                }
            }

            if (validInput == true)
            {
                if (!string.IsNullOrEmpty(addProductPriceText.Text))
                {
                    try
                    {
                        productPrice = Convert.ToDouble(addProductPriceText.Text);
                    }
                    catch (Exception EX)
                    {
                        addProductlbl.Text = $"Product's price error: {EX.Message}";
                        validInput = false;
                    }
                }
                else
                {
                    addProductlbl.Text = "Product's price error: It was left blank!";
                    validInput = false;
                }
            }

            if (validInput == true && productPrice <= 0)
            {
                addProductlbl.Text = "Product's price error: Price must be more than 0!";
                validInput = false;
            }

            if (validInput == true)
            {
                if (!string.IsNullOrEmpty(addProductQuantityText.Text))
                {
                    try
                    {
                        productQuantity = Convert.ToInt32(addProductQuantityText.Text);
                    }
                    catch (Exception EX)
                    {
                        addProductlbl.Text = $"Product's quantity in stock error: {EX.Message}";
                        validInput = false;
                    }
                }
                else
                {
                    addProductlbl.Text = "Product's quantity in stock error: It was left blank!";
                    validInput = false;
                }
            }

            if (validInput == true && productQuantity < 0)
            {
                addProductlbl.Text = "Product's quantity in stock error: Quantity in stock must be more than or equal to 0!";
                validInput = false;
            }

            if (validInput == true)
            {
                query = $"INSERT INTO Products (ProductID, ProductName, Category, Price, QuantityInStock) VALUES ('{productID}', '{productName}', '{productCategory}', {productPrice}, {productQuantity})";
                cmd = new SqlCommand(query, global.con);
                reader = cmd.ExecuteReader();
                addProductlbl.Text = $"Product {productID} was added!";
                reader.Close();
            }
            global.con.Close();
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            string productID = "";
            bool productFound = false;
            bool validInput = true;

            if (!string.IsNullOrEmpty(searchProductText.Text))
            {
                try
                {
                    productID = searchProductText.Text;
                }
                catch (Exception EX)
                {
                    productFoundlbl.Text = $"Product's ID error: {EX.Message}";
                    validInput = false;
                }
            }
            else
            {
                productFoundlbl.Text = "Product's ID error: It was left blank!";
                validInput = false;
            }

            if (validInput == true)
            {
                global.con.Open();
                string query = "SELECT * FROM Products";
                SqlCommand cmd = new SqlCommand(query, global.con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    if (productID == reader.GetString(0))
                    {
                        sNamelbl.Text = reader.GetString(1);
                        sCategorylbl.Text = reader.GetString(2);
                        sPricelbl.Text = "R" + Convert.ToString(reader.GetDouble(3));
                        sQuantitylbl.Text = Convert.ToString(reader.GetInt32(4));
                        productFound = true;
                    }
                }
                reader.Close();
                global.con.Close();

                if (productFound == true)
                {
                    productFoundlbl.Text = $"Product {productID} was found!";
                }
                else
                {
                    productFoundlbl.Text = $"Product {productID} was not found!";
                }
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            string productCategory = "", productID = "";
            int productQuantity = 0;
            double productPrice = 0.0;
            bool productFound = false, validInput = true;

            if (!string.IsNullOrEmpty(updateProductIDText.Text))
            {
                try
                {
                    productID = updateProductIDText.Text;
                }
                catch (Exception EX)
                {
                    updateProductlbl.Text = $"Product's ID error: {EX.Message}";
                    validInput = false;
                }
            }
            else
            {
                updateProductlbl.Text = "Product's ID error: It was left blank!";
                validInput = false;
            }

            if (validInput == true)
            {
                if (!string.IsNullOrEmpty(updateProductCategoryText.Text))
                {
                    try
                    {
                        productCategory = updateProductCategoryText.Text;
                    }
                    catch (Exception EX)
                    {
                        updateProductlbl.Text = $"Product's category error: {EX.Message}";
                        validInput = false;
                    }
                }
                else
                {
                    updateProductlbl.Text = "Product's category error: It was left blank!";
                    validInput = false;
                }
            }

            if (validInput == true)
            {
                if (!string.IsNullOrEmpty(updateProductPriceText.Text))
                {
                    try
                    {
                        productPrice = Convert.ToDouble(updateProductPriceText.Text);
                    }
                    catch (Exception EX)
                    {
                        updateProductlbl.Text = $"Product's price error: {EX.Message}";
                        validInput = false;
                    }
                }
                else
                {
                    updateProductlbl.Text = "Product's price error: It was left blank!";
                    validInput = false;
                }
            }

            if (validInput == true && productPrice <= 0)
            {
                updateProductlbl.Text = "Product's price error: Price must be more than 0!";
                validInput = false;
            }

            if (validInput == true)
            {
                if (!string.IsNullOrEmpty(updateProductQuantityText.Text))
                {
                    try
                    {
                        productQuantity = Convert.ToInt32(updateProductQuantityText.Text);
                    }
                    catch (Exception EX)
                    {
                        updateProductlbl.Text = $"Product's quantity in stock error: {EX.Message}";
                        validInput = false;
                    }
                }
                else
                {
                    updateProductlbl.Text = "Product's quantity in stock error: It was left blank!";
                    validInput = false;
                }
            }

            if (validInput == true && productQuantity < 0)
            {
                updateProductlbl.Text = "Product's quantity in stock error: Quantity in stock must be more than or equal to 0!";
                validInput = false;
            }

            if (validInput == true)
            {
                global.con.Open();
                string query = "SELECT productID FROM Products";
                SqlCommand cmd = new SqlCommand(query, global.con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    if (productID == reader.GetString(0))
                    {
                        productFound = true;
                    }
                }
                reader.Close();

                if (productFound == true)
                {
                    query = $"UPDATE Products SET Category = '{productCategory}', Price = {productPrice}, QuantityInStock = {productQuantity} WHERE productID = '{productID}'";
                    cmd = new SqlCommand(query, global.con);
                    reader = cmd.ExecuteReader();
                    updateProductlbl.Text = $"Product {productID} is updated!";
                    reader.Close();
                }
                else
                {
                    updateProductlbl.Text = $"Product {productID} was not found!";
                }
                global.con.Close();
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            string productID = "";
            bool productFound = false, validInput = true;

            if (!string.IsNullOrEmpty(deleteProductIDText.Text))
            {
                try
                {
                    productID = deleteProductIDText.Text;
                }
                catch (Exception EX)
                {
                    deleteProductlbl.Text = $"Product's ID error: {EX.Message}";
                    validInput = false;
                }
            }
            else
            {
                deleteProductlbl.Text = "Product's ID error: It was left blank!";
                validInput = false;
            }

            if (validInput == true)
            {
                global.con.Open();
                string query = "SELECT ProductID FROM Products";
                SqlCommand cmd = new SqlCommand(query, global.con);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    if (productID == reader.GetString(0))
                    {
                        productFound = true;
                    }
                }
                reader.Close();

                if (productFound == true)
                {

                    query = $"DELETE FROM Products WHERE ProductID = '{productID}'";
                    cmd = new SqlCommand(query, global.con);
                    reader = cmd.ExecuteReader();
                    deleteProductlbl.Text = $"Product {productID} is deleted!";
                    reader.Close();
                }
                else
                {
                    deleteProductlbl.Text = $"Product {productID} was not found!";
                }
                global.con.Close();
            }
        }

        private void InitializeComponent()
        {
            addBtn = new Button();
            addProductNameText = new TextBox();
            addProductCategoryText = new TextBox();
            addProductPriceText = new TextBox();
            addProductQuantityText = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            searchBtn = new Button();
            label12 = new Label();
            searchProductText = new TextBox();
            sNamelbl = new Label();
            sCategorylbl = new Label();
            sPricelbl = new Label();
            sQuantitylbl = new Label();
            productFoundlbl = new Label();
            label1 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            updateProductQuantityText = new TextBox();
            updateProductPriceText = new TextBox();
            updateProductCategoryText = new TextBox();
            addProductlbl = new Label();
            updateProductlbl = new Label();
            updateProductIDText = new TextBox();
            label16 = new Label();
            updateBtn = new Button();
            deleteProductBtn = new Button();
            deleteProductIDText = new TextBox();
            label17 = new Label();
            deleteProductlbl = new Label();
            label19 = new Label();
            bakeryNamelbl = new Label();
            SuspendLayout();
            // 
            // addBtn
            // 
            addBtn.Location = new Point(11, 106);
            addBtn.Name = "addBtn";
            addBtn.Size = new Size(75, 23);
            addBtn.TabIndex = 1;
            addBtn.Text = "Add product";
            addBtn.UseVisualStyleBackColor = true;
            addBtn.Click += addBtn_Click;
            // 
            // addProductNameText
            // 
            addProductNameText.Location = new Point(77, 153);
            addProductNameText.Name = "addProductNameText";
            addProductNameText.Size = new Size(100, 23);
            addProductNameText.TabIndex = 2;
            // 
            // addProductCategoryText
            // 
            addProductCategoryText.Location = new Point(77, 189);
            addProductCategoryText.Name = "addProductCategoryText";
            addProductCategoryText.Size = new Size(100, 23);
            addProductCategoryText.TabIndex = 3;
            // 
            // addProductPriceText
            // 
            addProductPriceText.Location = new Point(317, 151);
            addProductPriceText.Name = "addProductPriceText";
            addProductPriceText.Size = new Size(100, 23);
            addProductPriceText.TabIndex = 4;
            // 
            // addProductQuantityText
            // 
            addProductQuantityText.Location = new Point(317, 189);
            addProductQuantityText.Name = "addProductQuantityText";
            addProductQuantityText.Size = new Size(100, 23);
            addProductQuantityText.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(11, 161);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 6;
            label2.Text = "Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(11, 197);
            label3.Name = "label3";
            label3.Size = new Size(58, 15);
            label3.TabIndex = 7;
            label3.Text = "Category:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(205, 159);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 8;
            label4.Text = "Price:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(205, 197);
            label5.Name = "label5";
            label5.Size = new Size(100, 15);
            label5.TabIndex = 9;
            label5.Text = "Quantity in stock:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Rockwell Condensed", 20F, FontStyle.Bold);
            label6.Location = new Point(9, 72);
            label6.Name = "label6";
            label6.Size = new Size(168, 31);
            label6.TabIndex = 10;
            label6.Text = "Add a product";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Rockwell Condensed", 20F, FontStyle.Bold);
            label7.Location = new Point(540, 78);
            label7.Name = "label7";
            label7.Size = new Size(238, 31);
            label7.TabIndex = 20;
            label7.Text = "Search for a product";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(540, 244);
            label8.Name = "label8";
            label8.Size = new Size(100, 15);
            label8.TabIndex = 19;
            label8.Text = "Quantity in stock:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(542, 218);
            label9.Name = "label9";
            label9.Size = new Size(36, 15);
            label9.TabIndex = 18;
            label9.Text = "Price:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(542, 192);
            label10.Name = "label10";
            label10.Size = new Size(58, 15);
            label10.TabIndex = 17;
            label10.Text = "Category:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(542, 167);
            label11.Name = "label11";
            label11.Size = new Size(42, 15);
            label11.TabIndex = 16;
            label11.Text = "Name:";
            // 
            // searchBtn
            // 
            searchBtn.Location = new Point(542, 112);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(75, 23);
            searchBtn.TabIndex = 11;
            searchBtn.Text = "Search";
            searchBtn.UseVisualStyleBackColor = true;
            searchBtn.Click += searchBtn_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(638, 116);
            label12.Name = "label12";
            label12.Size = new Size(21, 15);
            label12.TabIndex = 21;
            label12.Text = "ID:";
            // 
            // searchProductText
            // 
            searchProductText.Location = new Point(665, 112);
            searchProductText.Name = "searchProductText";
            searchProductText.Size = new Size(100, 23);
            searchProductText.TabIndex = 22;
            // 
            // sNamelbl
            // 
            sNamelbl.AutoSize = true;
            sNamelbl.Location = new Point(665, 167);
            sNamelbl.Name = "sNamelbl";
            sNamelbl.Size = new Size(0, 15);
            sNamelbl.TabIndex = 23;
            // 
            // sCategorylbl
            // 
            sCategorylbl.AutoSize = true;
            sCategorylbl.Location = new Point(665, 192);
            sCategorylbl.Name = "sCategorylbl";
            sCategorylbl.Size = new Size(0, 15);
            sCategorylbl.TabIndex = 24;
            // 
            // sPricelbl
            // 
            sPricelbl.AutoSize = true;
            sPricelbl.Location = new Point(665, 218);
            sPricelbl.Name = "sPricelbl";
            sPricelbl.Size = new Size(0, 15);
            sPricelbl.TabIndex = 25;
            // 
            // sQuantitylbl
            // 
            sQuantitylbl.AutoSize = true;
            sQuantitylbl.Location = new Point(665, 244);
            sQuantitylbl.Name = "sQuantitylbl";
            sQuantitylbl.Size = new Size(0, 15);
            sQuantitylbl.TabIndex = 26;
            // 
            // productFoundlbl
            // 
            productFoundlbl.AutoSize = true;
            productFoundlbl.Location = new Point(540, 138);
            productFoundlbl.Name = "productFoundlbl";
            productFoundlbl.Size = new Size(0, 15);
            productFoundlbl.TabIndex = 27;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Rockwell Condensed", 20F, FontStyle.Bold);
            label1.Location = new Point(9, 266);
            label1.Name = "label1";
            label1.Size = new Size(200, 31);
            label1.TabIndex = 37;
            label1.Text = "Update a product";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(13, 439);
            label13.Name = "label13";
            label13.Size = new Size(100, 15);
            label13.TabIndex = 36;
            label13.Text = "Quantity in stock:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(13, 401);
            label14.Name = "label14";
            label14.Size = new Size(36, 15);
            label14.TabIndex = 35;
            label14.Text = "Price:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(13, 363);
            label15.Name = "label15";
            label15.Size = new Size(58, 15);
            label15.TabIndex = 34;
            label15.Text = "Category:";
            // 
            // updateProductQuantityText
            // 
            updateProductQuantityText.Location = new Point(125, 431);
            updateProductQuantityText.Name = "updateProductQuantityText";
            updateProductQuantityText.Size = new Size(100, 23);
            updateProductQuantityText.TabIndex = 32;
            // 
            // updateProductPriceText
            // 
            updateProductPriceText.Location = new Point(125, 393);
            updateProductPriceText.Name = "updateProductPriceText";
            updateProductPriceText.Size = new Size(100, 23);
            updateProductPriceText.TabIndex = 31;
            // 
            // updateProductCategoryText
            // 
            updateProductCategoryText.Location = new Point(125, 355);
            updateProductCategoryText.Name = "updateProductCategoryText";
            updateProductCategoryText.Size = new Size(100, 23);
            updateProductCategoryText.TabIndex = 30;
            // 
            // addProductlbl
            // 
            addProductlbl.AutoSize = true;
            addProductlbl.Location = new Point(11, 132);
            addProductlbl.Name = "addProductlbl";
            addProductlbl.Size = new Size(0, 15);
            addProductlbl.TabIndex = 38;
            // 
            // updateProductlbl
            // 
            updateProductlbl.AutoSize = true;
            updateProductlbl.Location = new Point(11, 326);
            updateProductlbl.Name = "updateProductlbl";
            updateProductlbl.Size = new Size(0, 15);
            updateProductlbl.TabIndex = 39;
            // 
            // updateProductIDText
            // 
            updateProductIDText.Location = new Point(125, 301);
            updateProductIDText.Name = "updateProductIDText";
            updateProductIDText.Size = new Size(100, 23);
            updateProductIDText.TabIndex = 41;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(98, 305);
            label16.Name = "label16";
            label16.Size = new Size(21, 15);
            label16.TabIndex = 40;
            label16.Text = "ID:";
            // 
            // updateBtn
            // 
            updateBtn.Location = new Point(11, 301);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(75, 23);
            updateBtn.TabIndex = 42;
            updateBtn.Text = "Update";
            updateBtn.UseVisualStyleBackColor = true;
            updateBtn.Click += updateBtn_Click;
            // 
            // deleteProductBtn
            // 
            deleteProductBtn.Location = new Point(540, 360);
            deleteProductBtn.Name = "deleteProductBtn";
            deleteProductBtn.Size = new Size(75, 23);
            deleteProductBtn.TabIndex = 47;
            deleteProductBtn.Text = "Delete";
            deleteProductBtn.UseVisualStyleBackColor = true;
            deleteProductBtn.Click += deleteBtn_Click;
            // 
            // deleteProductIDText
            // 
            deleteProductIDText.Location = new Point(654, 360);
            deleteProductIDText.Name = "deleteProductIDText";
            deleteProductIDText.Size = new Size(100, 23);
            deleteProductIDText.TabIndex = 46;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(627, 364);
            label17.Name = "label17";
            label17.Size = new Size(21, 15);
            label17.TabIndex = 45;
            label17.Text = "ID:";
            // 
            // deleteProductlbl
            // 
            deleteProductlbl.AutoSize = true;
            deleteProductlbl.Location = new Point(542, 336);
            deleteProductlbl.Name = "deleteProductlbl";
            deleteProductlbl.Size = new Size(0, 15);
            deleteProductlbl.TabIndex = 44;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Rockwell Condensed", 20F, FontStyle.Bold);
            label19.Location = new Point(542, 305);
            label19.Name = "label19";
            label19.Size = new Size(194, 31);
            label19.TabIndex = 43;
            label19.Text = "Delete a product";
            // 
            // bakeryNamelbl
            // 
            bakeryNamelbl.AutoSize = true;
            bakeryNamelbl.Font = new Font("Segoe UI Black", 25F, FontStyle.Bold | FontStyle.Underline);
            bakeryNamelbl.Location = new Point(9, 9);
            bakeryNamelbl.Name = "bakeryNamelbl";
            bakeryNamelbl.Size = new Size(350, 46);
            bakeryNamelbl.TabIndex = 48;
            bakeryNamelbl.Text = "Fluffy Bakes Bakery";
            // 
            // Form1
            // 
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(860, 470);
            Controls.Add(bakeryNamelbl);
            Controls.Add(deleteProductBtn);
            Controls.Add(deleteProductIDText);
            Controls.Add(label17);
            Controls.Add(deleteProductlbl);
            Controls.Add(label19);
            Controls.Add(updateBtn);
            Controls.Add(updateProductIDText);
            Controls.Add(label16);
            Controls.Add(updateProductlbl);
            Controls.Add(addProductlbl);
            Controls.Add(label1);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(updateProductQuantityText);
            Controls.Add(updateProductPriceText);
            Controls.Add(updateProductCategoryText);
            Controls.Add(productFoundlbl);
            Controls.Add(sQuantitylbl);
            Controls.Add(sPricelbl);
            Controls.Add(sCategorylbl);
            Controls.Add(sNamelbl);
            Controls.Add(searchProductText);
            Controls.Add(label12);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(searchBtn);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(addProductQuantityText);
            Controls.Add(addProductPriceText);
            Controls.Add(addProductCategoryText);
            Controls.Add(addProductNameText);
            Controls.Add(addBtn);
            ForeColor = SystemColors.ControlText;
            Name = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}

