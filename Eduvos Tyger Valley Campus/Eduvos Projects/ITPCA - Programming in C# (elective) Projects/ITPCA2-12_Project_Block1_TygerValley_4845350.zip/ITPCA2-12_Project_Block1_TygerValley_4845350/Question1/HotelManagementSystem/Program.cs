﻿namespace HotelManagementSystem
{
    internal class Program
    {
        public static int[] roomNum = { 101, 102, 103, 201, 202, 203, 301, 302, 303 };
        public static string[] roomName = { "", "", "", "", "", "", "", "", "" };
        public static bool[] roomAvailable = { true, true, true, true, true, true, true, true, true };
        public static bool[] roomCheckedIn = { false, false, false, false, false, false, false, false, false };

        static void bookRoom()
        {
            string fullName, roomType, line, guestList = "CurrentGuests.txt";
            DateTime checkInDate, checkOutDate;
            int min = 0, max = 0;
            bool roomFound = false, correctRoomType = true;

            Console.WriteLine("");
            if (File.Exists(guestList))
            {
                Console.Write("Enter Guest Name: ");
                fullName = Console.ReadLine();
                Console.Write("Enter Room Type (Single/Double/Suite): ");
                roomType = Console.ReadLine().ToLower();

                if (roomType == "single")
                {
                    min = 0;
                    max = 2;
                }
                else if (roomType == "double")
                {
                    min = 3;
                    max = 5;
                }
                else if (roomType == "suite")
                {
                    min = 6;
                    max = 8;
                }
                else
                {
                    correctRoomType = false;
                    Console.WriteLine("Invalid room type!");
                }

                if (correctRoomType == true)
                {
                    Console.Write("Enter Check-in Date (MM/DD/YYYY): ");
                    checkInDate = Convert.ToDateTime(Console.ReadLine());
                    Console.Write("Enter Check-out Date (MM/DD/YYYY): ");
                    checkOutDate = Convert.ToDateTime(Console.ReadLine());

                    for (int i = min; i <= max; i++)
                    {
                        if (roomAvailable[i] == true && roomFound == false)
                        {
                            roomName[i] = fullName;
                            roomAvailable[i] = false;
                            roomFound = true;
                            line = $"{Convert.ToString(roomNum[i])},{fullName},{checkInDate.ToString("MM/dd/yyyy")},{checkOutDate.ToString("MM/dd/yyyy")}";
                            File.WriteAllText(guestList, line);
                            Console.WriteLine($"Room {roomNum[i]} booked for {fullName} from {checkInDate.ToString("MM/dd/yyyy")} to {checkOutDate.ToString("MM/dd/yyyy")}.");
                        }
                    }
                    if (roomFound == false) {
                        Console.WriteLine($"No {roomType} rooms are available.");
                    }
                }
            }
            else
            {
                Console.WriteLine("Guest list file not found!");
            }
            Console.WriteLine("");
        }

        static void checkIn()
        {
            string fullName;
            int roomNumber;
            bool roomFound = false;

            Console.WriteLine("");
            Console.WriteLine("Enter Guest Name: ");
            fullName = Console.ReadLine();
            Console.WriteLine("Enter Room Number: ");
            roomNumber = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < 9; i++)
            {
                if (roomNumber == roomNum[i])
                {
                    roomFound = true;
                    if (fullName == roomName[i])
                    {
                        roomCheckedIn[i] = true;
                    }
                    else
                    {
                        Console.WriteLine($"Room {roomNumber} was not assigned to {fullName}.");
                    }
                }
            }

            if (roomFound == false)
            {
                Console.WriteLine($"Room {roomNumber} does not exist.");
            }
            Console.WriteLine("");
        }

        static void checkOut()
        {
            int roomNumber, index = 0;
            bool roomFound = false;

            Console.WriteLine("");
            Console.Write("Enter Room Number: ");
            roomNumber = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < 9; i++)
            {
                if (roomNumber == roomNum[i])
                {
                    roomFound = true;
                    index = i;
                    if (roomCheckedIn[i] == true)
                    {
                        Console.WriteLine($"Room {roomNumber} is now available to new guests.");
                    }
                }
            }

            if (roomFound == false)
            {
                Console.WriteLine($"Room {roomNumber} does not exist.");
            }
            else if (roomCheckedIn[index] == false)
            {
                Console.WriteLine($"Room {roomNumber} is already available.");
            }
            else
            {
                roomName[index] = "";
                roomAvailable[index] = true;
                roomCheckedIn[index] = false;
            }
            Console.WriteLine("");
        }

        static void history()
        {
            string fullName = "", roomNumber = "", checkInDate = "", checkOutDate = "", guestList = "CurrentGuests.txt";
            int linePhase = 0;

            Console.WriteLine("");
            Console.WriteLine("Reservation History:");
            if (File.Exists(guestList))
            {
                foreach (string line in File.ReadLines(guestList))
                {
                    for (int i = 0; i < line.Length; i++)
                    {
                        if (line[i] != ',')
                        {
                            if (linePhase == 0)
                            {
                                roomNumber = roomNumber + line[i];
                            }
                            else if (linePhase == 1)
                            {
                                fullName = fullName + line[i];
                            }
                            else if (linePhase == 2)
                            {
                                checkInDate = checkInDate + line[i];
                            }
                            else
                            {
                                checkOutDate = checkOutDate + line[i];
                            }
                        }
                        else
                        {
                            linePhase++;
                        }
                    }
                }
                Console.WriteLine($"Room {roomNumber}, Guest: {fullName}, From: {checkInDate}, To: {checkOutDate}");
            }
            else
            {
                Console.WriteLine("Guest list file not found!");
            }
            Console.WriteLine("");
        }

        static void viewRooms()
        {
            string roomType;
            int noRoomFound = 0;

            Console.WriteLine("");
            Console.WriteLine("Available rooms:");
            for (int i = 0; i < 9; i++)
            {
                if (roomAvailable[i] == true)
                {
                    if (i < 3)
                    {
                        roomType = "Single";
                    }
                    else if (i >= 3 && i < 6)
                    {
                        roomType = "Double";
                    }
                    else
                    {
                        roomType = "Suite";
                    }
                    Console.WriteLine($"Room {roomNum[i]} ({roomType})");
                }
                else
                {
                    noRoomFound++;
                }
            }
            if (noRoomFound == 9)
            {
                Console.WriteLine("No rooms are available at the moment!");
            }
            Console.WriteLine("");
        }

        static void Main(string[] args)
        {
            bool exitSystem = false;
            int option;

            do
            {
                Console.WriteLine("1. Book Room");
                Console.WriteLine("2. Check-in Guest");
                Console.WriteLine("3. Check-out Guest");
                Console.WriteLine("4. View Available Rooms");
                Console.WriteLine("5. View Reservation History");
                Console.WriteLine("6. Exit");
                Console.Write("Enter an option: ");

                option = Convert.ToInt32(Console.ReadLine());

                switch(option)
                {
                    case 1:
                        {
                            bookRoom();
                            break;
                        }
                    case 2:
                        {
                            checkIn();
                            break;
                        }
                    case 3:
                        {
                            checkOut();
                            break;
                        }
                    case 4:
                        {
                            viewRooms();
                            break;
                        }
                    case 5:
                        {
                            history();
                            break;
                        }
                    case 6:
                        {
                            exitSystem = true;
                            Console.WriteLine("Exiting program...");
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid option!");
                            break;
                        }
                }
            } while (exitSystem == false);
        }
    }
}
