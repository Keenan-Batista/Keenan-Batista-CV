﻿//Keenan Batista, 4845350

using System.Collections.Generic;
using System.Linq;

namespace StudentCourseEnrollmentSystem
{
    internal class Program
    {
        class enrollmentClass
        {
            public string student_Name { get; set; }
            public int student_ID { get; set; }
            public string student_course {  get; set; }
        }

        class global
        {
            static public LinkedList<enrollmentClass> studentEnrollment = new LinkedList<enrollmentClass>();
            static public string selectedCourse = "";
        }

        static void addStudent()
        {
            string name = "";
            int studentID = 0;
            bool studentFound = false, invalidInput = false;

            Console.Write("Enter the student's name: ");
            try
            {
                name = Console.ReadLine();
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
                invalidInput = true;
            }

            if (invalidInput == false)
            {
                Console.Write("Enter the student's ID: ");
                try
                {
                    studentID = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                    invalidInput = true;
                }
            }

            if (invalidInput == false)
            {
                foreach (var student in global.studentEnrollment)
                {
                    if (student.student_ID == studentID)
                    {
                        studentFound = true;
                        Console.WriteLine("The student is already in the course!");
                    }

                }

                if (studentFound == false)
                {
                    global.studentEnrollment.AddLast(new enrollmentClass { student_Name = name, student_ID = studentID, student_course = global.selectedCourse.ToLower() });
                    Console.WriteLine("The student has been successfully added to the course!");
                }
            }
        }

        static void removeStudent()
        {
            string name = "";
            int studentID = 0;
            bool studentFound = false, invalidInput = false;
            var studentDetails = global.studentEnrollment.First;

            Console.Write("Enter the student's ID: ");
            try
            {
                studentID = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
                invalidInput = true;
            }

            if (invalidInput == false)
            {
                while (studentDetails != null)
                {
                    if (studentDetails.Value.student_ID == studentID && studentDetails.Value.student_course == global.selectedCourse.ToLower())
                    {
                        studentFound = true;
                        global.studentEnrollment.Remove(studentDetails);
                        Console.WriteLine("The student has been successfully removed from the course!");
                    }
                    studentDetails = studentDetails.Next;
                }

                if (studentFound == false)
                {
                    Console.WriteLine("The student was not found in this course!\n");
                }
            }
        }

        static void displayAllStudents()
        {
            bool studentFound = false;

            foreach (var student in global.studentEnrollment)
            {
                if (student.student_course == global.selectedCourse.ToLower())
                {
                    studentFound = true;
                }
            }

            if (studentFound == true)
            {
                Console.WriteLine("Enrolled students:\n");
                foreach (var student in global.studentEnrollment)
                {
                    if (student.student_course == global.selectedCourse.ToLower())
                    {
                        Console.WriteLine($"Name: {student.student_Name}, ID: {student.student_ID}");
                    }
                }
            }
            else
            {
                Console.WriteLine("No students have enrolled for this course!");
            }
        }

        static void Main(string[] args)
        {
            bool exitProgram = false, invalidInput = false, exitCourse = true;
            int option = 0;

            Console.WriteLine("Welcome to the student course enrollment system!");
            do
            {
                invalidInput = false;
                Console.WriteLine("\n1. Enter a specific course.");
                Console.WriteLine("2. Exit the program.");

                Console.Write("\nEnter the option you would like to perform: ");
                try
                {
                    option = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                    invalidInput = true;
                }

                if (invalidInput == false)
                {
                    switch (option)
                    {
                        case 1:
                            Console.Write("\nEnter the course that you would like to manage (ITSEA, ITPCA, ITDSA): ");
                            try
                            {
                                global.selectedCourse = Console.ReadLine();
                            }
                            catch (Exception error)
                            {
                                Console.WriteLine(error.Message);
                                invalidInput = true;
                            }

                            if (invalidInput == false) {
                                if (global.selectedCourse.ToLower() == "itsea" || global.selectedCourse.ToLower() == "itpca" || global.selectedCourse.ToLower() == "itpca")
                                {
                                    exitCourse = false;
                                }
                                else
                                {
                                    Console.WriteLine("Invalid course!");
                                }
                            }
                            break;
                        case 2:
                            exitProgram = true;
                            break;
                        default:
                            Console.WriteLine("Invalid option!");
                            break;
                    }
                }

                while (exitCourse == false)
                {
                    invalidInput = false;
                    Console.WriteLine($"\nYou are managing the {global.selectedCourse.ToLower()} course!");
                    Console.WriteLine("1. Add a student to the course.");
                    Console.WriteLine("2. Remove a student from the course.");
                    Console.WriteLine("3. Display all students that are enrolled in this course.");
                    Console.WriteLine("4. Exit this course.");

                    Console.Write("\nEnter the option you would like to perform: ");
                    try
                    {
                        option = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception error)
                    {
                        Console.WriteLine(error.Message);
                        invalidInput = true;
                    }

                    if (invalidInput == false)
                    {
                        switch (option)
                        {
                            case 1:
                                addStudent();
                                break;
                            case 2:
                                removeStudent();
                                break;
                            case 3:
                                displayAllStudents();
                                break;
                            case 4:
                                exitCourse = true;
                                Console.Write("\nExisting course .....\n");
                                break;
                            default:
                                Console.WriteLine("Invalid option!");
                                break;
                        }
                    }
                }
            } while (exitProgram == false);
            Console.Write("\nExisting program .....");
        }
    }
}
