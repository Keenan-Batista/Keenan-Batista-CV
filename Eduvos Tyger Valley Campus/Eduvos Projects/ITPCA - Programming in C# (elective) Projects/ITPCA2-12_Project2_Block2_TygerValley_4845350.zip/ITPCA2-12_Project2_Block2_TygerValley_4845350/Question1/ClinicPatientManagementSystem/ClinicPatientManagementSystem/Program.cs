﻿//Keenan Batista, 4845350

using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ClinicPatientManagementSystem
{
    internal class Program
    {
        public static string[] patientName = new string[10], patientCondition = new string[10];
        public static int[] patientAge = new int[10];

        static void addPatient()
        {
            string name = "", condition = "";
            int age = 0;
            bool patientAdded = false, invalidInput = false;

            if (patientName[9] == null)
            {
                Console.Write("Enter the patient's name: ");
                try
                {
                    name = Console.ReadLine();
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                    invalidInput = true;
                }

                if (invalidInput == false)
                {
                    Console.Write("Enter the patient's age: ");
                    try
                    {
                        age = Convert.ToInt32(Console.ReadLine());
                    }
                    catch (Exception error)
                    {
                        Console.WriteLine(error.Message);
                        invalidInput = true;
                    }
                }

                if (invalidInput == false)
                {
                    if (age <= 0 || age > 120)
                    {
                        Console.WriteLine("Invalid age! The patient's age must be between 0 and 120!");
                        invalidInput = true;
                    }
                }

                if (invalidInput == false)
                {
                    Console.Write("Enter the patient's medical condition: ");
                    try
                    {
                        condition = Console.ReadLine();
                    }
                    catch (Exception error)
                    {
                        Console.WriteLine(error.Message);
                        invalidInput = true;
                    }
                }

                if (invalidInput == false)
                {
                    for (int loop = 0; loop < patientName.Length; loop++)
                    {
                        if (patientName[loop] == null && patientAdded == false)
                        {
                            patientAdded = true;
                            patientName[loop] = name;
                            patientAge[loop] = age;
                            patientCondition[loop] = condition;
                            Console.WriteLine("Patient successfully added!");
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Patient limit reached!");
            }
            Console.WriteLine("");
        }

        static void removePatient()
        {
            string name = "";
            int removedIndex = 0;
            bool patientFound = false, invalidInput = false;

            if (patientName[0] == null)
            {
                Console.WriteLine("No patient records to display.");
            }
            else
            {
                Console.Write("Enter the patient's name: ");
                try
                {
                    name = Console.ReadLine();
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                    invalidInput = true;
                }

                if (invalidInput == false)
                {
                    for (int loop = 0; loop < patientName.Length; loop++)
                    {
                        if (patientName[loop] == null)
                        {
                            loop = patientName.Length;
                        }
                        else
                        {
                            if (patientName[loop].ToLower() == name.ToLower())
                            {
                                patientFound = true;
                                patientName[loop] = null;
                                patientAge[loop] = 0;
                                patientCondition[loop] = null;
                                removedIndex = loop;
                                Console.WriteLine("Patient has been removed successfully!");
                            }
                        }
                    }

                    if (patientFound == false)
                    {
                        Console.WriteLine("Patient not found.");
                    }
                    else
                    {
                        if (removedIndex < 9)
                        {
                            for (int loop = (removedIndex + 1); loop < patientName.Length; loop++)
                            {
                                patientName[loop - 1] = patientName[loop];
                                patientAge[loop - 1] = patientAge[loop];
                                patientCondition[loop - 1] = patientName[loop];
                                patientName[loop] = null;
                                patientAge[loop] = 0;
                                patientCondition[loop] = null;
                            }
                        }
                    }
                }
            }
            Console.WriteLine("");
        }

        static void searchPatient()
        {
            string name = "";
            bool patientFound = false, invalidInput = false;

            if (patientName[0] == null)
            {
                Console.WriteLine("No patient records to search for.");
            }
            else
            {
                Console.Write("Enter the patient's name: ");
                try
                {
                    name = Console.ReadLine();
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                    invalidInput = true;
                }

                if (invalidInput == false)
                {
                    for (int loop = 0; loop < patientName.Length; loop++)
                    {
                        if (patientName[loop] == null)
                        {
                            loop = patientName.Length;
                        }
                        else
                        {
                            if (patientName[loop].ToLower() == name.ToLower() && patientFound == false)
                            {
                                patientFound = true;
                                Console.WriteLine($"Patient's name: {patientName[loop]}");
                                Console.WriteLine($"Patient's age: {patientAge[loop]}");
                                Console.WriteLine($"Patient's medical condition: {patientCondition[loop]}");
                            }
                        }
                    }

                    if (patientFound == false)
                    {
                        Console.WriteLine("Patient not found.");
                    }
                }
            }
            Console.WriteLine("");
        }

        static void displayAllPatients()
        {
            if (patientName[0] == null)
            {
                Console.WriteLine("No patient records to display.");
                Console.WriteLine("");
            }
            else
            {
                for (int loop = 0; loop < patientName.Length; loop++)
                {
                    if (patientName[loop] == null)
                    {
                        loop = patientName.Length;
                    }
                    else
                    {
                        Console.WriteLine($"Patient's name: {patientName[loop]}");
                        Console.WriteLine($"Patient's age: {patientAge[loop]}");
                        Console.WriteLine($"Patient's medical condition: {patientCondition[loop]}");
                        Console.WriteLine("");
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            int option = 0;
            bool mainMenu = true, invalidInput = false;

            do {
                invalidInput = false;
                Console.WriteLine("-----Main Menu-----");
                Console.WriteLine("1. Add a patient");
                Console.WriteLine("2. Remove a patient");
                Console.WriteLine("3. Search for a patient");
                Console.WriteLine("4. Display all patients");
                Console.WriteLine("5. Exit program");
                Console.WriteLine("");
                Console.Write("Enter an option: ");

                try
                {
                    option = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                    invalidInput = true;
                }
                Console.WriteLine("");

                if (invalidInput == false)
                {
                    switch (option)
                    {
                        case 1:
                            addPatient();
                            break;
                        case 2:
                            removePatient();
                            break;
                        case 3:
                            searchPatient();
                            break;
                        case 4:
                            displayAllPatients();
                            break;
                        case 5:
                            Console.WriteLine("Existing program....");
                            mainMenu = false;
                            break;
                        default:
                            Console.WriteLine("Invalid option! Try again!");
                            break;
                    }
                }
            } while (mainMenu == true);
        }
    }
}
