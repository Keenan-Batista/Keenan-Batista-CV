﻿//Keenan Batista, 4845350

using System.Threading;

namespace DroneRacingSimulation
{
    internal class Program
    {
        public static class Global
        {
            public const int totalDistance = 25;
            public static int dronesFinished = 0;
            public static int[] arrDistance = { 0, 0, 0, 0, 0 };
            public static int[] arrDroneEndPosition = { 0, 0, 0, 0, 0 };
        }

        static void drone1Racing(int distance)
        {
            string additionalText = "";

            Thread.Sleep(distance * 100);
            Global.arrDistance[0] += distance;
            if (Global.arrDistance[0] >= Global.totalDistance)
            {
                additionalText = ", Drone 1 has completed race!";
                Global.dronesFinished += 1;
                Global.arrDroneEndPosition[0] = Global.dronesFinished;

            }
            Console.WriteLine($"Drone 1 has covered {distance}km, Total distance covered so far {Global.arrDistance[0]}km{additionalText}");
        }

        static void drone2Racing(int distance)
        {
            string additionalText = "";

            Thread.Sleep(distance * 100);
            Global.arrDistance[1] += distance;
            if (Global.arrDistance[1] >= Global.totalDistance)
            {
                additionalText = ", Drone 2 has completed race!";
                Global.dronesFinished += 1;
                Global.arrDroneEndPosition[1] = Global.dronesFinished;

            }
            Console.WriteLine($"Drone 2 has covered {distance}km, Total distance covered so far {Global.arrDistance[1]}km{additionalText}");
        }

        static void drone3Racing(int distance)
        {
            string additionalText = "";

            Thread.Sleep(distance * 100);
            Global.arrDistance[2] += distance;
            if (Global.arrDistance[2] >= Global.totalDistance)
            {
                additionalText = ", Drone 3 has completed race!";
                Global.dronesFinished += 1;
                Global.arrDroneEndPosition[2] = Global.dronesFinished;

            }
            Console.WriteLine($"Drone 3 has covered {distance}km, Total distance covered so far {Global.arrDistance[2]}km{additionalText}");
        }

        static void drone4Racing(int distance)
        {
            string additionalText = "";

            Thread.Sleep(distance * 100);
            Global.arrDistance[3] += distance;
            if (Global.arrDistance[3] >= Global.totalDistance)
            {
                additionalText = ", Drone 4 has completed race!";
                Global.dronesFinished += 1;
                Global.arrDroneEndPosition[3] = Global.dronesFinished;

            }
            Console.WriteLine($"Drone 4 has covered {distance}km, Total distance covered so far {Global.arrDistance[3]}km{additionalText}");
        }

        static void drone5Racing(int distance)
        {
            string additionalText = "";

            Thread.Sleep(distance * 100);
            Global.arrDistance[4] += distance;
            if (Global.arrDistance[4] >= Global.totalDistance)
            {
                additionalText = ", Drone 5 has completed race!";
                Global.dronesFinished += 1;
                Global.arrDroneEndPosition[4] = Global.dronesFinished;

            }
            Console.WriteLine($"Drone 5 has covered {distance}km, Total distance covered so far {Global.arrDistance[4]}km{additionalText}");
        }

        static int randomDistance()
        {
            Random randomDistance = new Random();
            return randomDistance.Next(1, 9);
        }

        static void Main(string[] args)
        {
            int sectionNum = 1;

            Task drone1 = Task.Run(() => drone1Racing(randomDistance()));
            Task drone2 = Task.Run(() => drone2Racing(randomDistance()));
            Task drone3 = Task.Run(() => drone3Racing(randomDistance()));
            Task drone4 = Task.Run(() => drone4Racing(randomDistance()));
            Task drone5 = Task.Run(() => drone5Racing(randomDistance()));

            Console.WriteLine("Welcome to Drone Racing Simulation!");
            Console.WriteLine("Racing begins ..... Drones must travel 25km!");

            do {
                Console.WriteLine($"\n--- Section {sectionNum} ---\n");
                Task.WaitAll(drone1, drone2, drone3, drone4, drone5);

                if (Global.arrDistance[0] < Global.totalDistance) {
                    drone1 = Task.Run(() => drone1Racing(randomDistance()));
                }
                if (Global.arrDistance[1] < Global.totalDistance)
                {
                    drone2 = Task.Run(() => drone2Racing(randomDistance()));
                }
                if (Global.arrDistance[2] < Global.totalDistance)
                {
                    drone3 = Task.Run(() => drone3Racing(randomDistance()));
                }
                if (Global.arrDistance[3] < Global.totalDistance)
                {
                    drone4 = Task.Run(() => drone4Racing(randomDistance()));
                }
                if (Global.arrDistance[4] < Global.totalDistance)
                {
                    drone5 = Task.Run(() => drone5Racing(randomDistance()));
                }

                sectionNum++;
            } while (Global.dronesFinished < 5);

            Console.WriteLine("\n---- Podium ----");
            for (int i = 0; i < Global.arrDroneEndPosition.Length; i++)
            {
                for (int j = 0; j < Global.arrDroneEndPosition.Length; j++)
                {
                    string position = "th";
                    if (Global.arrDroneEndPosition[j] == (i + 1))
                    {
                        if (Global.arrDroneEndPosition[j] == 1)
                        {
                            position = "st";
                        }
                        else if (Global.arrDroneEndPosition[j] == 2)
                        {
                            position = "nd";
                        }
                        Console.WriteLine($"Drone {j + 1} got {Global.arrDroneEndPosition[j]}{position} in the competition!");
                    }
                }
            }
        }
    }
}
