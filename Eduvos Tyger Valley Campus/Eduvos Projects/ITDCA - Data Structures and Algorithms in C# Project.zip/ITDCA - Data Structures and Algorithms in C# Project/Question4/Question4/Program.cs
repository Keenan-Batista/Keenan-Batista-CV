﻿using System.Text.Json.Nodes;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Question4
{
    internal class Program
    {
        public class HotelDetails
        {
            //Specify the details of each hotel record
            public int id { get; set; }
            public string name { get; set; }
            public double nightly_rate { get; set; }
            public double stars { get; set; }
            public double distance_from_airport { get; set; }
        }

        static double Partition(List<HotelDetails> hotelList, double lowNum, double highNum, string sortBy)
        {
            double i = (lowNum - 1);

            //Seperate the way that the list is sorted depending on if the metric is a string or double value
            if (sortBy == "name")
            {
                //Define the pivot for the quick sort
                string strPivot = hotelList[Convert.ToInt32(highNum)].name;
                List<string> list = new List<string>();

                //Add the metric values to a new list that will be used for quick sorting
                foreach (var record in hotelList)
                {
                    list.Add(record.name);
                }

                //Compare the hotel names and swap accordingly
                for (double j = lowNum; j < highNum; j++)
                {
                    if (string.Compare(list[Convert.ToInt32(j)], strPivot) < 0)
                    {
                        i++;
                        SwapRecords(hotelList, i, j);
                    }
                }
            }
            else
            {
                //Define the pivot for the quick sort
                double dobPivot = 0.00;
                List<double> list = new List<double>();

                //Add the metric values to a new list that will be used for quick sorting depnding on the metric chosen by the user
                if (sortBy == "rate")
                {
                    dobPivot = hotelList[Convert.ToInt32(highNum)].nightly_rate;
                    foreach (var record in hotelList)
                    {
                        list.Add(record.nightly_rate);
                    }
                }
                else if (sortBy == "stars")
                {
                    dobPivot = hotelList[Convert.ToInt32(highNum)].stars;
                    foreach (var record in hotelList)
                    {
                        list.Add(record.stars);
                    }
                }
                else if (sortBy == "distance")
                {
                    dobPivot = hotelList[Convert.ToInt32(highNum)].distance_from_airport;
                    foreach (var record in hotelList)
                    {
                        list.Add(record.distance_from_airport);
                    }
                }

                //Compare the double metric values and swap accordingly
                for (double j = lowNum; j < highNum; j++)
                {
                    if (list[Convert.ToInt32(j)] < dobPivot)
                    {
                        i++;
                        SwapRecords(hotelList, i, j);
                    }
                }
            }

            SwapRecords(hotelList, i + 1, highNum);
            return (i + 1);
        }

        static void SwapRecords(List<HotelDetails> hotelList, double i, double j)
        {
            //Swap hotel details
            HotelDetails tempDetails = hotelList[Convert.ToInt32(i)];
            hotelList[Convert.ToInt32(i)] = hotelList[Convert.ToInt32(j)];
            hotelList[Convert.ToInt32(j)] = tempDetails;
        }

        static void QuickSort(List<HotelDetails> hotelList, double lowNum, double highNum, string sortBy)
        {
            //Perform quick sorting
            if (lowNum < highNum)
            {
                double pi = Partition(hotelList, lowNum, highNum, sortBy);
                QuickSort(hotelList, lowNum, pi - 1, sortBy);
                QuickSort(hotelList, pi + 1, highNum, sortBy);
            }
        }

        static void DisplayList(string sortBy, List<HotelDetails> hotelList)
        {
            //Copy the data from hotelList to sortedList so that hotelList remains unchanged
            List<HotelDetails> sortedList = new List<HotelDetails>(hotelList);

            //Sort the data in sortedList based on the user's choice
            if (sortBy != ""){
                QuickSort(sortedList, 0, sortedList.Count - 1, sortBy);
            }

            //Display the sorted data in sortedList
            foreach (var record in sortedList)
            {
                Console.WriteLine($"id: {record.id}");
                Console.WriteLine($"name: {record.name}");
                Console.WriteLine($"nightly_rate: {record.nightly_rate}");
                Console.WriteLine($"stars: {record.stars}");
                Console.WriteLine($"distance_from_airport: {record.distance_from_airport}\n");
            }
        }

        static void Main(string[] args)
        {
            //Initialise variables
            bool dataFound = false, exitProgram = false;
            List<HotelDetails> hotelList = new List<HotelDetails>();

            //Determine if the json file can be found and read from and catch any errors that could occur
            try {
                //Read from the json file and store the data into hotelList
                using (StreamReader data = new StreamReader("q4_data (1).json"))
                {
                    string file = data.ReadToEnd();
                    hotelList = JsonSerializer.Deserialize<List<HotelDetails>>(file);
                }

                dataFound = true;
                Console.WriteLine("Json file was successfully read!");
            }
            catch (Exception error)
            {
                //Display an appropriate error message
                Console.WriteLine($"Error! {error.Message}");
            }

            if (dataFound == true) {
                do
                {
                    //Ask user to view the data in hoteList based on the option that they pick
                    int option = 0;

                    Console.WriteLine("\n1. View hotel list without sorting");
                    Console.WriteLine("2. View hotel list according to it's name");
                    Console.WriteLine("3. View hotel list according to it's nightly rate");
                    Console.WriteLine("4. View hotel list according to it's stars");
                    Console.WriteLine("5. View hotel list according to it's distance from the airport");
                    Console.WriteLine("6. Exit proram\n");

                    //Determine if the option is valid and catch any errors
                    Console.Write("Enter your option: ");
                    try
                    {
                        option = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("");

                        //Perform operations based on the user's choice
                        switch (option)
                        {
                            case 1:
                                DisplayList("", hotelList);
                                break;

                            case 2:
                                DisplayList("name", hotelList);
                                break;

                            case 3:
                                DisplayList("rate", hotelList);
                                break;

                            case 4:
                                DisplayList("stars", hotelList);
                                break;

                            case 5:
                                DisplayList("distance", hotelList);
                                break;

                            case 6:
                                exitProgram = true;
                                Console.WriteLine("Exiting proram .....");
                                break;

                            default:
                                //Display an appropriate error message
                                Console.WriteLine("Invalid option!");
                                break;
                        }
                    }
                    catch (Exception error)
                    {
                        //Display an appropriate error message
                        Console.WriteLine("\nInvalid option!");
                    }
                } while (exitProgram == false);
            }
        }
    }
}
