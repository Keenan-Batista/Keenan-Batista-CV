﻿using System.Xml.Linq;

namespace Question1
{
    public class q1_BookDetails
    {
        public string title { get; set; }
        public string author { get; set; }
        public int year { get; set; }

        public q1_BookDetails(string Title, string Author, int Year)
        {
            title = Title;
            author = Author;
            year = Year;
        }
    }

    public class q1_AVL_Tree
    {
        public q1_AVL_Tree left;
        public q1_AVL_Tree right;
        public q1_BookDetails details;
        public int height;

        public q1_AVL_Tree(q1_BookDetails book)
        {
            left = null;
            right = null;
            details = book;
            height = 1;
        }

        public static q1_AVL_Tree InsertEntry(q1_AVL_Tree tree, q1_BookDetails details)
        {
            if (tree == null)
            {
                Console.WriteLine("Book successfully added to the AVL tree.\n");
                return new q1_AVL_Tree(details);
            }

            if (details.year < tree.details.year)
            {
                tree.left = InsertEntry(tree.left, details);
            }
            else if (details.year > tree.details.year)
            {
                tree.right = InsertEntry(tree.right, details);
            }
            else
            {
                Console.WriteLine($"Book couldn't be added as another book with the year {details.year} already exists in the AVL tree.\n");
            }

            tree.height = (1 + Math.Max(GetTreeHeight(tree.left), GetTreeHeight(tree.right)));
            int balance = CalcBalance(tree);

            if (balance > 1 && details.year < tree.left.details.year)
            {
                return TreeRightRotate(tree);
            }

            if (balance < -1 && details.year > tree.right.details.year)
            {
                return TreeLeftRotate(tree);
            }

            if (balance > 1 && details.year > tree.left.details.year)
            {
                tree.left = TreeLeftRotate(tree.left);
                return TreeRightRotate(tree);
            }

            if (balance < -1 && details.year < tree.right.details.year)
            {
                tree.right = TreeRightRotate(tree.right);
                return TreeLeftRotate(tree);
            }

            return tree;
        }

        public static q1_AVL_Tree RemoveEntry(q1_AVL_Tree tree, int year, bool foundBook)
        {
            if (tree == null)
            {
                Console.WriteLine($"No book with the year {year} was found in the AVL tree.\n");
                return tree;
            }

            if (year < tree.details.year)
            {
                tree.left = RemoveEntry(tree.left, year, foundBook);
            }
            else if (year > tree.details.year)
            {
                tree.right = RemoveEntry(tree.right, year, foundBook);
            }
            else
            {
                if (foundBook == false)
                {
                    Console.WriteLine("Book removed successfully from the AVL tree.\n");
                    foundBook = true;
                }

                if (tree.left == null || tree.right == null)
                {
                    q1_AVL_Tree temp = null;

                    if (tree.left != null)
                    {
                        temp = tree.left;
                        tree = temp;
                    }
                    else if (tree.right != null)
                    {
                        temp = tree.right;
                        tree = temp;
                    }
                    else
                    {
                        tree = temp;
                    }
                }
                else
                {
                    q1_AVL_Tree currentTree = tree.right;
                    while (currentTree.left != null)
                    {
                        currentTree = currentTree.left;
                    }
                    q1_AVL_Tree temp = currentTree;

                    tree.details = temp.details;
                    tree.right = RemoveEntry(tree.right, temp.details.year, foundBook);
                }
            }

            if (tree == null)
            {
                return tree;
            }

            tree.height = (1 + Math.Max(GetTreeHeight(tree.left), GetTreeHeight(tree.right)));
            int balance = CalcBalance(tree);

            if (balance > 1 && CalcBalance(tree.left) >= 0)
            {
                return TreeRightRotate(tree);
            }

            if (balance > 1 && CalcBalance(tree.left) < 0)
            {
                tree.left = TreeLeftRotate(tree.left);
                return TreeRightRotate(tree);
            }

            if (balance < -1 && CalcBalance(tree.right) <= 0)
            {
                return TreeLeftRotate(tree);
            }

            if (balance < -1 && CalcBalance(tree.right) > 0)
            {
                tree.right = TreeRightRotate(tree.right);
                return TreeLeftRotate(tree);
            }

            return tree;
        }

        static q1_AVL_Tree TreeRightRotate(q1_AVL_Tree y)
        {
            q1_AVL_Tree x = y.left;
            q1_AVL_Tree temp = x.right;
            x.right = y;
            y.left = temp;

            y.height = (1 + Math.Max(GetTreeHeight(y.left), GetTreeHeight(y.right)));
            x.height = (1 + Math.Max(GetTreeHeight(x.left), GetTreeHeight(x.right)));
            return x;
        }

        static q1_AVL_Tree TreeLeftRotate(q1_AVL_Tree x)
        {
            q1_AVL_Tree y = x.right;
            q1_AVL_Tree temp = y.left;
            y.left = x;
            x.right = temp;

            y.height = (1 + Math.Max(GetTreeHeight(y.left), GetTreeHeight(y.right)));
            x.height = (1 + Math.Max(GetTreeHeight(x.left), GetTreeHeight(x.right)));
            return y;
        }

        public static int CalcBalance(q1_AVL_Tree tree)
        {
            return (GetTreeHeight(tree.left) - GetTreeHeight(tree.right));
        }

        public static int GetTreeHeight(q1_AVL_Tree tree)
        {
            if (tree == null)
            {
                return 0;
            }
            return tree.height;
        }

        public static void ViewAllEntries(q1_AVL_Tree tree)
        {
            if (tree != null)
            {
                ViewAllEntries(tree.left);
                Console.WriteLine($"Book title: {tree.details.title} | Book author: {tree.details.author} | Book year: {tree.details.year}");
                ViewAllEntries(tree.right);
            }
        }
    }

    internal class q1_Program
    {
        static q1_BookDetails CreateEntry()
        {
            string name = null, author = null;
            int year = 0;

            try
            {
                Console.Write("Enter the book's name: ");
                name = Console.ReadLine();
                Console.Write("Enter the book's author: ");
                author = Console.ReadLine();
                Console.Write("Enter the book's year: ");
                year = Convert.ToInt32(Console.ReadLine());

                return new q1_BookDetails(name, author, year);
            }
            catch (Exception error)
            {
                Console.WriteLine($"{error.Message}\n");
                return null;
            }
        }

        static int AskBookYear()
        {
            int year = 0;

            try
            {
                Console.Write("Enter the book's year: ");
                year = Convert.ToInt32(Console.ReadLine());

                return year;
            }
            catch (Exception error)
            {
                Console.WriteLine($"{error.Message}\n");
                return -1;
            }
        }

        static void Main(string[] args)
        {
            int option = 0;
            bool exitProgram = false;
            q1_AVL_Tree rootTree = null;

            List<q1_BookDetails> sampleData = new List<q1_BookDetails>
        {
            new q1_BookDetails("The Silent Patient", "Alex Michaelides", 2019),
            new q1_BookDetails("The Great Gatsby", "F. Scott Fitzgerald", 1925),
            new q1_BookDetails("To Kill a Mockingbird", "Harper Lee", 1960),
            new q1_BookDetails("1984", "George Orwell", 1949),
            new q1_BookDetails("The Catcher in the Rye", "J.D. Salinger", 1951),
            new q1_BookDetails("Pride and Prejudice", "Jane Austen", 1813),
            new q1_BookDetails("Moby-Dick", "Herman Melville", 1851),
            new q1_BookDetails("The Hobbit", "J.R.R. Tolkien", 1937),
            new q1_BookDetails("Brave New World", "Aldous Huxley", 1932),
            new q1_BookDetails("The Book Thief", "Markus Zusak", 2005),
            new q1_BookDetails("The Road", "Cormac McCarthy", 2006),
            new q1_BookDetails("Harry Potter and the Sorcerer's Stone", "J.K. Rowling", 1997),
            new q1_BookDetails("The Girl with the Dragon Tattoo", "Stieg Larsson", 2005),
            new q1_BookDetails("The Alchemist", "Paulo Coelho", 1988),
            new q1_BookDetails("The Shining", "Stephen King", 1977),
            new q1_BookDetails("Wuthering heights", "Emily Brontë", 1847),
            new q1_BookDetails("Catch-22", "Joseph Heller", 1961),
            new q1_BookDetails("The Hunger Games", "Suzanne Collins", 2008),
            new q1_BookDetails("The Da Vinci Code", "Dan Brown", 2003),
            new q1_BookDetails("The Outsiders", "S.E. Hinton", 1967)
        };

            foreach (var item in sampleData)
            {
                rootTree = q1_AVL_Tree.InsertEntry(rootTree, item);
            }

            Console.WriteLine("----- Welcome the book collection system -----");

            do
            {
                Console.WriteLine("\n1. Add a book");
                Console.WriteLine("2. Remove a book");
                Console.WriteLine("3. View all book entry details");
                Console.WriteLine("4. Exit the program\n");

                Console.Write("Enter your option here: ");
                try
                {
                    option = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("");

                    q1_BookDetails book = null;
                    switch (option)
                    {
                        case 1:
                            book = CreateEntry();

                            if (book != null)
                            {
                                rootTree = q1_AVL_Tree.InsertEntry(rootTree, book);
                            }
                            break;
                        case 2:
                            int year = AskBookYear();

                            if (year != -1)
                            {
                                rootTree = q1_AVL_Tree.RemoveEntry(rootTree, year, false);
                            }
                            break;
                        case 3:
                            Console.WriteLine("AVL tree in full: ");
                            q1_AVL_Tree.ViewAllEntries(rootTree);
                            break;
                        case 4:
                            exitProgram = true;
                            Console.WriteLine("Exiting the program .....");
                            break;
                        default:
                            Console.WriteLine("\nInvalid option!");
                            break;
                    }
                }
                catch (Exception error)
                {
                    Console.WriteLine($"\n{error.Message}\n");
                }
            } while (exitProgram == false);
        }
    }
}
