﻿using System.Xml.Linq;

namespace ClinicTicketingSystem
{
    internal class q3_Program
    {
        public class q3_Global
        {
            static public PriorityQueue<string, int> pQueue = new PriorityQueue<string, int>();
        }

        static void DequeueAllPatientsFromQueue()
        {
            //Determine if there are any patients in the queue and create an appropriate message
            if (q3_Global.pQueue.Count > 0)
            {
                do
                {
                    q3_Global.pQueue.TryDequeue(out string pName, out int pLvl);
                    Console.WriteLine($"Patient name: {pName} | Priority level: {pLvl}");
                    Console.WriteLine("");
                }
                while (q3_Global.pQueue.Count > 0);
            }
            else
            {
                Console.WriteLine("No patient records are in the priority queue. Please enter patient records before attempting to perform this option.");
                Console.WriteLine("");
            }
        }

        static void DequeuePatientFromQueue()
        {
            //Determine if there are any patients in the queue and create an appropriate message
            if (q3_Global.pQueue.Count > 0)
            {
                q3_Global.pQueue.TryDequeue(out string pName, out int pLvl);
                Console.WriteLine($"Patient name: {pName} | Priority level: {pLvl}");
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine("No patient records are in the priority queue. Please enter patient records before attempting to perform this option.");
                Console.WriteLine("");
            }
        }

        static void AddPatientToQueue()
        {
            //Initiliasie variables
            string name = "";
            int priorityLvl = 0;

            //Input the patient's name
            Console.Write("Enter the patient's name: ");
            name = Console.ReadLine();

            //Input the patient's priority level and determine if the input is invalid
            try
            {
                Console.Write("Enter the patient's priority level (0 is the highest level, 4 is the lowest level): ");
                priorityLvl = Convert.ToInt32(Console.ReadLine());

                //Determine if the priority level is within the defined limits
                if (priorityLvl >= 0 && priorityLvl <= 4)
                {
                    q3_Global.pQueue.Enqueue(name, priorityLvl);
                    Console.WriteLine("");
                    Console.WriteLine("Patient successfully added!\n");
                }
                else
                {
                    Console.WriteLine("");
                    Console.WriteLine($"Error! Invalid priority level! The priority level MUST be between 0 and 4!\n");
                }
            }
            catch (Exception error)
            {
                Console.WriteLine("");
                Console.WriteLine($"Error! Invalid priority level! {error.Message}\n");
            }
        }

        static void Main(string[] args)
        {
            //Initiliasie variables
            bool exitProgram = false;
            int option = 0;
            Console.WriteLine("------ Welcome to the Patient Ticketing System ------");

            //Repeat this code until the user specifies that they want to exit the program
            do
            {
                Console.WriteLine("1. Enqueue a new patient");
                Console.WriteLine("2. Dequeue a patient");
                Console.WriteLine("3. Dequeue all patients");
                Console.WriteLine("4. Exit the program\n");
                Console.Write("Select an option: ");

                //Determine if the user's input is valid to prevent errors
                try
                {
                    option = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("");

                    //Perform certain actions depending on which option the user performs and create a message if the input is invalid
                    switch (option)
                    {
                        case 1:
                            AddPatientToQueue();
                            break;
                        case 2:
                            DequeuePatientFromQueue();
                            break;
                        case 3:
                            DequeueAllPatientsFromQueue();
                            break;
                        case 4:
                            exitProgram = true;
                            Console.WriteLine("Exiting program .....");
                            break;
                        default:
                            Console.WriteLine("Error! Invalid option!\n");
                            break;
                    }
                }
                catch (Exception error)
                {
                    Console.WriteLine($"Error! Invalid option! {error.Message}\n");
                }
            } while (exitProgram == false);

        }
    }
}
