﻿using System;
using System.Xml.Linq;
using Microsoft.VisualBasic.FileIO;

namespace Question2
{
    public class q2_BookDetails
    {
        //Create a class that contains a book's title, author and year
        public string title { get; set; }
        public string author { get; set; }
        public int year { get; set; }

        //Initialise the class variables
        public q2_BookDetails(string Title, string Author, int Year)
        {
            title = Title;
            author = Author;
            year = Year;
        }
    }

    public class q2_AVL_Tree
    {
        //Create the variables for the q2_AVL_Tree class
        public q2_AVL_Tree left;
        public q2_AVL_Tree right;
        public q2_BookDetails details;
        public int height;
        public static int totalNum = 0;

        //Initialise the class variables
        public q2_AVL_Tree(q2_BookDetails book)
        {
            left = null;
            right = null;
            details = book;
            height = 1;
        }

        public static q2_AVL_Tree InsertEntry(q2_AVL_Tree tree, q2_BookDetails details)
        {
            //Insert the book into the AVL tree, increment the total number of books and display an appropriate message
            if (tree == null)
            {
                Console.WriteLine("Book successfully added to the AVL tree.\n");
                totalNum++;
                return new q2_AVL_Tree(details);
            }

            //Determine if the book's year is more or less than the current tree's book year and start a new InsertEntry() with either left or right value of the current tree
            if (details.year < tree.details.year)
            {
                tree.left = InsertEntry(tree.left, details);
            }
            else if (details.year > tree.details.year)
            {
                tree.right = InsertEntry(tree.right, details);
            }
            else
            {
                //If a book from the tree has the same year as the book that the user wants to add to the AVL tree, this message will be displayed
                Console.WriteLine($"Book couldn't be added as another book with the year {details.year} already exists in the AVL tree.\n");
            }

            //The height of the current tree is updated and the balance is then calculated
            tree.height = (1 + Math.Max(GetTreeHeight(tree.left), GetTreeHeight(tree.right)));
            int balance = CalcBalance(tree);

            //If the current tree is unbalanced, the information will be rotated according to how the tree is unbalanced

            //Performing a left left rotation
            if (balance > 1 && details.year < tree.left.details.year)
            {
                return TreeRightRotate(tree);
            }

            //Performing a right right rotation
            if (balance < -1 && details.year > tree.right.details.year)
            {
                return TreeLeftRotate(tree);
            }

            //Performing a left right rotation
            if (balance > 1 && details.year > tree.left.details.year)
            {
                tree.left = TreeLeftRotate(tree.left);
                return TreeRightRotate(tree);
            }

            //Performing a right left rotation
            if (balance < -1 && details.year < tree.right.details.year)
            {
                tree.right = TreeRightRotate(tree.right);
                return TreeLeftRotate(tree);
            }

            return tree;
        }

        public static q2_AVL_Tree RemoveEntry(q2_AVL_Tree tree, int year, bool foundBook)
        {
            //Display an appropriate message if no books with the inputted year is found
            if (tree == null)
            {
                Console.WriteLine($"No book with the year {year} was found in the AVL tree.\n");
                return tree;
            }

            //Determine if the book's year is more or less than the current tree's book year and start a new RemoveEntry() with either left or right value of the current tree
            if (year < tree.details.year)
            {
                tree.left = RemoveEntry(tree.left, year, foundBook);
            }
            else if (year > tree.details.year)
            {
                tree.right = RemoveEntry(tree.right, year, foundBook);
            }
            else
            {
                //Display an appropriate message if a book's year from the current tree matches the inputted year and decrement the total number of books in the AVL tree
                if (foundBook == false)
                {
                    Console.WriteLine("Book removed successfully from the AVL tree.\n");
                    totalNum--;
                    foundBook = true;
                }

                if (tree.left == null || tree.right == null)
                {
                    q2_AVL_Tree temp = null;

                    //Assign the temp value based on if the tree has a left, right or no value at all and then update the current tree to the temp
                    if (tree.left != null)
                    {
                        temp = tree.left;
                        tree = temp;
                    }
                    else if (tree.right != null)
                    {
                        temp = tree.right;
                        tree = temp;
                    }
                    else
                    {
                        tree = temp;
                    }
                }
                else
                {
                    q2_AVL_Tree currentTree = tree.right;
                    //Get the left most book from the AVL tree, which will be the book with the earliest year, and store it into the temp value
                    while (currentTree.left != null)
                    {
                        currentTree = currentTree.left;
                    }
                    q2_AVL_Tree temp = currentTree;

                    //Update the current tree's book details with the temp's book details
                    tree.details = temp.details;
                    tree.right = RemoveEntry(tree.right, temp.details.year, foundBook);
                }
            }

            //Return the current tree if there was only one node in the AVL tree
            if (tree == null)
            {
                return tree;
            }

            //The height of the current tree is updated and the balance is then calculated
            tree.height = (1 + Math.Max(GetTreeHeight(tree.left), GetTreeHeight(tree.right)));
            int balance = CalcBalance(tree);

            //If the current tree is unbalanced, the information will be rotated according to how the tree is unbalanced

            //Performing a left left rotation
            if (balance > 1 && CalcBalance(tree.left) >= 0)
            {
                return TreeRightRotate(tree);
            }

            //Performing a left right rotation
            if (balance > 1 && CalcBalance(tree.left) < 0)
            {
                tree.left = TreeLeftRotate(tree.left);
                return TreeRightRotate(tree);
            }

            //Performing a right right rotation
            if (balance < -1 && CalcBalance(tree.right) <= 0)
            {
                return TreeLeftRotate(tree);
            }

            //Performing a right left rotation
            if (balance < -1 && CalcBalance(tree.right) > 0)
            {
                tree.right = TreeRightRotate(tree.right);
                return TreeLeftRotate(tree);
            }

            return tree;
        }

        static q2_AVL_Tree TreeRightRotate(q2_AVL_Tree y)
        {
            q2_AVL_Tree x = y.left;
            q2_AVL_Tree temp = x.right;

            //The values are rotated
            x.right = y;
            y.left = temp;

            //The heights of both values will be updated
            y.height = (1 + Math.Max(GetTreeHeight(y.left), GetTreeHeight(y.right)));
            x.height = (1 + Math.Max(GetTreeHeight(x.left), GetTreeHeight(x.right)));
            return x;
        }

        static q2_AVL_Tree TreeLeftRotate(q2_AVL_Tree x)
        {
            q2_AVL_Tree y = x.right;
            q2_AVL_Tree temp = y.left;

            //The values are rotated
            y.left = x;
            x.right = temp;

            //The heights of both values will be updated
            y.height = (1 + Math.Max(GetTreeHeight(y.left), GetTreeHeight(y.right)));
            x.height = (1 + Math.Max(GetTreeHeight(x.left), GetTreeHeight(x.right)));
            return y;
        }

        //Calculate the balance of the current tree
        public static int CalcBalance(q2_AVL_Tree tree)
        {
            return (GetTreeHeight(tree.left) - GetTreeHeight(tree.right));
        }

        //Return the height value of the current tree
        public static int GetTreeHeight(q2_AVL_Tree tree)
        {
            if (tree == null)
            {
                return 0;
            }
            return tree.height;
        }

        public static void ViewAllEntries(q2_AVL_Tree tree)
        {
            //Display all book details in order of it's year in the AVL tree
            if (tree != null)
            {
                ViewAllEntries(tree.left);
                Console.WriteLine($"Book title: {tree.details.title} | Book author: {tree.details.author} | Book year: {tree.details.year}");
                ViewAllEntries(tree.right);
            }
        }

        public static void InOrderTraversal(q2_AVL_Tree tree)
        {
            //Display all book titles in order of it's year in the AVL tree
            if (tree != null)
            {
                InOrderTraversal(tree.left);
                Console.WriteLine($"Book title: {tree.details.title}");
                InOrderTraversal(tree.right);
            }
        }

        public static q2_BookDetails SearchByYear(q2_AVL_Tree tree, int year)
        {
            bool stopLoop = false;
            //Loop through the AVL tree by going left or right depending on the size difference between inputted year and the current book's year
            do
            {
                //Return the book's details if the year matches the inputted year
                if (tree.details.year == year)
                {
                    return tree.details;
                }
                else if (tree.details.year > year)
                {
                    if (tree.left != null)
                    {
                        tree = tree.left;
                    }
                    else
                    {
                        //End the loop when the year hasn't been found and the left value is null
                        stopLoop = true;
                    }
                }
                else if (tree.details.year < year)
                {
                    if (tree.right != null)
                    {
                        //End the loop when the year hasn't been found and the right value is null
                        tree = tree.right;
                    }
                    else
                    {
                        stopLoop = true;
                    }
                }
            } while (stopLoop == false);

            //Return a null value to indicate that a book with the inputted year is not in the AVL tree
            return null;
        }

        public static q2_BookDetails MostRecent(q2_AVL_Tree tree)
        {
            bool stopLoop = false;
            //Loop through the AVL tree until it gets to the right most book, since it would have the most recent year
            do
            {
                if (tree.right != null)
                {
                    tree = tree.right;
                }
                else
                {
                    stopLoop = true;
                }
            } while (stopLoop == false);

            return tree.details;
        }

        //Display a message that shows the total number of books
        public static void TotalBooks()
        {
            Console.Write($"The total number of books in the AVL tree is {totalNum} books.\n");
        }
    }

    internal class q2_Program
    {
        static q2_BookDetails CreateEntry()
        {
            string name = null, author = null;
            int year = 0;

            //Ask the user to input the details of a book and return the values as well as determine if any errors occur
            try
            {
                Console.Write("Enter the book's name: ");
                name = Console.ReadLine();
                Console.Write("Enter the book's author: ");
                author = Console.ReadLine();
                Console.Write("Enter the book's year: ");
                year = Convert.ToInt32(Console.ReadLine());

                return new q2_BookDetails(name, author, year);
            }
            catch (Exception error)
            {
                Console.WriteLine($"{error.Message}\n");
                return null;
            }
        }

        static int AskBookYear()
        {
            int year = 0;

            //Ask the user to input the book's year and return it as well as determine if any errors occur
            try
            {
                Console.Write("Enter the book's year: ");
                year = Convert.ToInt32(Console.ReadLine());

                return year;
            }
            catch (Exception error)
            {
                Console.WriteLine($"{error.Message}\n");
                return -1;
            }
        }

        static void SearchForBook(q2_AVL_Tree tree)
        {
            int year = AskBookYear();

            //Search for a book with the inputted year and display the appropriate message
            if (year != -1) {
                q2_BookDetails book = q2_AVL_Tree.SearchByYear(tree, year);

                if (book == null)
                {
                    Console.WriteLine($"No books from the year {year} were found!\n");
                }
                else
                {
                    Console.WriteLine($"Book title: {book.title} | Book author: {book.author} | Book year: {book.year}\n");
                }
            }
        }

        //Get the most recent book and display all the books details in a message
        static void GetRecentBook(q2_AVL_Tree tree)
        {
            q2_BookDetails book = q2_AVL_Tree.MostRecent(tree);
            Console.Write($"The most recent book is:\n      Book title: {book.title} | Book author: {book.author} | Book year: {book.year}\n");
        }

        static void Main(string[] args)
        {
            //Initialise the variables and store the sample data
            int option = 0;
            bool exitProgram = false;
            q2_AVL_Tree rootTree = null;

            List<q2_BookDetails> sampleData = new List<q2_BookDetails>
        {
            new q2_BookDetails("The Silent Patient", "Alex Michaelides", 2019),
            new q2_BookDetails("The Great Gatsby", "F. Scott Fitzgerald", 1925),
            new q2_BookDetails("To Kill a Mockingbird", "Harper Lee", 1960),
            new q2_BookDetails("1984", "George Orwell", 1949),
            new q2_BookDetails("The Catcher in the Rye", "J.D. Salinger", 1951),
            new q2_BookDetails("Pride and Prejudice", "Jane Austen", 1813),
            new q2_BookDetails("Moby-Dick", "Herman Melville", 1851),
            new q2_BookDetails("The Hobbit", "J.R.R. Tolkien", 1937),
            new q2_BookDetails("Brave New World", "Aldous Huxley", 1932),
            new q2_BookDetails("The Book Thief", "Markus Zusak", 2005),
            new q2_BookDetails("The Road", "Cormac McCarthy", 2006),
            new q2_BookDetails("Harry Potter and the Sorcerer's Stone", "J.K. Rowling", 1997),
            new q2_BookDetails("The Girl with the Dragon Tattoo", "Stieg Larsson", 2005),
            new q2_BookDetails("The Alchemist", "Paulo Coelho", 1988),
            new q2_BookDetails("The Shining", "Stephen King", 1977),
            new q2_BookDetails("Wuthering heights", "Emily Brontë", 1847),
            new q2_BookDetails("Catch-22", "Joseph Heller", 1961),
            new q2_BookDetails("The Hunger Games", "Suzanne Collins", 2008),
            new q2_BookDetails("The Da Vinci Code", "Dan Brown", 2003),
            new q2_BookDetails("The Outsiders", "S.E. Hinton", 1967)
        };

            //Add all the sample data to the tree
            foreach (var item in sampleData)
            {
                rootTree = q2_AVL_Tree.InsertEntry(rootTree, item);
            }

            Console.WriteLine("----- Welcome the book collection system -----");

            do
            {
                Console.WriteLine("\n1. Add a book");
                Console.WriteLine("2. Remove a book");
                Console.WriteLine("3. View all book entry details");
                Console.WriteLine("4. In-order traversal");
                Console.WriteLine("5. Search by year");
                Console.WriteLine("6. Display most recent book");
                Console.WriteLine("7. Display the total number of books");
                Console.WriteLine("8. Exit the program\n");

                //Perform a task based on the option picked by the user and determine if any issues occur
                Console.Write("Enter your option here: ");
                try
                {
                    option = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("");

                    q2_BookDetails book = null;
                    switch (option)
                    {
                        case 1:
                            book = CreateEntry();

                            if (book != null)
                            {
                                rootTree = q2_AVL_Tree.InsertEntry(rootTree, book);
                            }
                            break;
                        case 2:
                            int year = AskBookYear();

                            if (year != -1)
                            {
                                rootTree = q2_AVL_Tree.RemoveEntry(rootTree, year, false);
                            }
                            break;
                        case 3:
                            Console.WriteLine("AVL tree in full: ");
                            q2_AVL_Tree.ViewAllEntries(rootTree);
                            break;
                        case 4:
                            Console.WriteLine("AVL tree in full: ");
                            q2_AVL_Tree.InOrderTraversal(rootTree);
                            break;
                        case 5:
                            SearchForBook(rootTree);
                            break;
                        case 6:
                            GetRecentBook(rootTree);
                            break;
                        case 7:
                            q2_AVL_Tree.TotalBooks();
                            break;
                        case 8:
                            exitProgram = true;
                            Console.WriteLine("\nExiting the program .....");
                            break;
                        default:
                            Console.WriteLine("\nInvalid option!");
                            break;
                    }
                }
                catch (Exception error)
                {
                    Console.WriteLine($"\n{error.Message}\n");
                }
            } while (exitProgram == false);
        }
    }
}
